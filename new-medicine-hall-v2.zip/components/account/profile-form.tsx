'use client'

import { useActionState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { updateProfileAction, type FormState } from '@/lib/actions/auth'

export function ProfileForm({ fullName, phone, email }: { fullName: string; phone: string; email: string }) {
  const [state, action, pending] = useActionState<FormState, FormData>(updateProfileAction, undefined)
  return (
    <form action={action} className="flex flex-col gap-4">
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="email">ইমেইল</Label>
        <Input id="email" value={email} disabled readOnly />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="full_name">পুরো নাম</Label>
        <Input id="full_name" name="full_name" defaultValue={fullName} required />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="phone">মোবাইল নম্বর</Label>
        <Input id="phone" name="phone" type="tel" defaultValue={phone} required pattern="01[0-9]{9}" />
      </div>
      {state?.error && <p role="alert" className="rounded-lg bg-destructive/10 p-2.5 text-sm text-destructive">{state.error}</p>}
      {state?.message && <p role="status" className="rounded-lg bg-chart-5/10 p-2.5 text-sm text-chart-5">{state.message}</p>}
      <Button type="submit" className="w-fit rounded-full" disabled={pending}>
        {pending ? 'সংরক্ষণ হচ্ছে…' : 'সংরক্ষণ করুন'}
      </Button>
    </form>
  )
}
