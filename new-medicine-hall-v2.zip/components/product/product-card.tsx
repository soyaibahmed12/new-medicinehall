'use client'

import Image from 'next/image'
import Link from 'next/link'
import { Heart, ShoppingCart, Star } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { QuantityStepper } from '@/components/cart/quantity-stepper'
import { type Product, bn, discountPercent, formatTaka } from '@/lib/catalog'
import { useShop } from '@/lib/store'
import { useRequireLogin } from '@/components/auth/auth-context'
import { cn } from '@/lib/utils'

export function ProductCard({ product, className }: { product: Product; className?: string }) {
  const pack = product.packs[0]
  const off = discountPercent(pack)
  const line = useShop((s) => s.cart.find((l) => l.productId === product.id && l.packId === pack.id))
  const wished = useShop((s) => s.wishlist.includes(product.id))
  const add = useShop((s) => s.add)
  const setQty = useShop((s) => s.setQty)
  const remove = useShop((s) => s.remove)
  const toggleWish = useShop((s) => s.toggleWish)
  const requireLogin = useRequireLogin()
  const outOfStock = product.stock <= 0

  return (
    <article
      className={cn(
        'group relative flex flex-col overflow-hidden rounded-2xl border bg-card transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-lg',
        className,
      )}
    >
      <div className="absolute top-2 left-2 z-10 flex flex-col gap-1">
        {off > 0 && <Badge className="bg-deal text-deal-foreground">{bn(off)}% ছাড়</Badge>}
      </div>
      <Button
        variant="secondary"
        size="icon-sm"
        aria-label={wished ? 'উইশলিস্ট থেকে সরান' : 'উইশলিস্টে যোগ করুন'}
        aria-pressed={wished}
        onClick={() =>
          requireLogin(() => {
            toggleWish(product.id, product)
            toast.success(wished ? 'উইশলিস্ট থেকে সরানো হয়েছে' : 'উইশলিস্টে যোগ হয়েছে')
          })
        }
        className="absolute top-2 right-2 z-10 rounded-full bg-card/90 shadow-sm"
      >
        <Heart className={cn(wished && 'fill-destructive text-destructive')} />
      </Button>

      <Link href={`/product/${product.slug}`} className="relative aspect-square bg-muted/60">
        <Image
          src={product.image}
          alt={`${product.name} ${product.strength}`}
          fill
          sizes="(min-width: 1024px) 20vw, (min-width: 640px) 33vw, 50vw"
          className={cn('object-contain p-4 transition-transform duration-300 group-hover:scale-105', outOfStock && 'opacity-50 grayscale')}
        />
        {outOfStock && (
          <span className="absolute inset-x-3 bottom-3 rounded-full bg-foreground/80 py-1 text-center text-xs font-semibold text-background">
            স্টক শেষ
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col gap-1.5 p-3">
        <p className="truncate text-[11px] font-medium text-muted-foreground uppercase">{product.company}</p>
        <Link href={`/product/${product.slug}`} className="line-clamp-2 min-h-10 text-sm leading-5 font-semibold hover:text-primary">
          {product.name} <span className="font-normal text-muted-foreground">{product.strength}</span>
        </Link>
        <p className="truncate text-xs text-muted-foreground">
          {product.form} · {product.generic}
        </p>
        <div className="flex items-center gap-1 text-xs">
          <Star className="size-3.5 fill-chart-4 text-chart-4" aria-hidden="true" />
          <span className="font-semibold">{bn(product.rating)}</span>
          <span className="text-muted-foreground">({bn(product.reviews)})</span>
          <span className="ml-auto text-muted-foreground">{bn(product.sold)}+ বিক্রি</span>
        </div>
        <div className="mt-auto flex items-end justify-between gap-2 pt-1">
          <div className="flex flex-col">
            <span className="text-lg leading-none font-bold text-primary">{formatTaka(pack.price)}</span>
            {off > 0 && <span className="text-xs text-muted-foreground line-through">{formatTaka(pack.mrp)}</span>}
          </div>
          <span className="truncate text-right text-[11px] text-muted-foreground">{pack.label}</span>
        </div>
        {line ? (
          <QuantityStepper
            size="sm"
            className="mt-1 w-full justify-between"
            value={line.qty}
            max={Math.min(20, product.stock)}
            onChange={(q) => setQty(product.id, pack.id, q)}
          />
        ) : (
          <Button
            className="mt-1 w-full rounded-full"
            disabled={outOfStock}
            onClick={() =>
              requireLogin(() => {
                add(product.id, pack.id, 1, product)
                toast.success(`${product.name} কার্টে যোগ হয়েছে`, {
                  action: { label: 'বাতিল', onClick: () => remove(product.id, pack.id) },
                })
              })
            }
          >
            <ShoppingCart data-icon="inline-start" />
            {outOfStock ? 'স্টক শেষ' : 'কার্টে যোগ করুন'}
          </Button>
        )}
      </div>
    </article>
  )
}
