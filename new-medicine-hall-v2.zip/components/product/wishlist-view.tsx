'use client'

import Link from 'next/link'
import { Heart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ProductCard } from '@/components/product/product-card'
import { useShop } from '@/lib/store'

export function WishlistView() {
  const wishlist = useShop((s) => s.wishlist)
  const snapshots = useShop((s) => s.snapshots)
  const hydrated = useShop((s) => s.hydrated)
  if (!hydrated) return null
  const items = wishlist.map((id) => snapshots[id]).filter(Boolean)
  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <h1 className="mb-6 flex items-center gap-2 text-xl font-bold">
        <Heart className="size-5 text-destructive" aria-hidden="true" /> আমার উইশলিস্ট
      </h1>
      {items.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed p-10 text-center">
          <p className="text-sm text-muted-foreground">উইশলিস্ট খালি। পছন্দের পণ্যে হার্ট আইকনে ক্লিক করুন।</p>
          <Button nativeButton={false} render={<Link href="/products" />}>কেনাকাটা শুরু করুন</Button>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
          {items.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  )
}
