'use client'

import { useState } from 'react'
import { Heart, ShoppingCart } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { QuantityStepper } from '@/components/cart/quantity-stepper'
import { discountPercent, formatTaka, type Product } from '@/lib/catalog'
import { useShop } from '@/lib/store'
import { useRequireLogin } from '@/components/auth/auth-context'
import { cn } from '@/lib/utils'

export function AddToCartPanel({ product }: { product: Product }) {
  const [packId, setPackId] = useState(product.packs[0].id)
  const pack = product.packs.find((p) => p.id === packId) ?? product.packs[0]
  const off = discountPercent(pack)
  const outOfStock = product.stock <= 0

  const line = useShop((s) => s.cart.find((l) => l.productId === product.id && l.packId === pack.id))
  const wished = useShop((s) => s.wishlist.includes(product.id))
  const add = useShop((s) => s.add)
  const setQty = useShop((s) => s.setQty)
  const remove = useShop((s) => s.remove)
  const toggleWish = useShop((s) => s.toggleWish)
  const requireLogin = useRequireLogin()
  const setCartOpen = useShop((s) => s.setCartOpen)

  return (
    <div className="flex flex-col gap-4">
      {product.packs.length > 1 && (
        <div className="flex flex-wrap gap-2">
          {product.packs.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPackId(p.id)}
              className={cn(
                'rounded-xl border px-3 py-2 text-left text-xs transition-colors',
                p.id === packId ? 'border-primary bg-primary/5 text-primary' : 'hover:bg-muted',
              )}
            >
              <span className="block font-semibold">{p.label}</span>
              <span className="text-muted-foreground">{formatTaka(p.price)}</span>
            </button>
          ))}
        </div>
      )}

      <div className="flex items-end gap-2">
        <span className="text-3xl font-bold text-primary">{formatTaka(pack.price)}</span>
        {off > 0 && (
          <>
            <span className="mb-1 text-sm text-muted-foreground line-through">{formatTaka(pack.mrp)}</span>
            <span className="mb-1 text-sm font-semibold text-deal">{off.toLocaleString('bn-BD')}% ছাড়</span>
          </>
        )}
      </div>

      <div className="flex items-center gap-3">
        {line ? (
          <QuantityStepper
            value={line.qty}
            max={Math.min(20, product.stock)}
            onChange={(q) => setQty(product.id, pack.id, q)}
            className="h-11"
          />
        ) : (
          <Button
            size="lg"
            className="flex-1 rounded-full"
            disabled={outOfStock}
            onClick={() =>
              requireLogin(() => {
                add(product.id, pack.id, 1, product)
                toast.success(`${product.name} কার্টে যোগ হয়েছে`, {
                  action: { label: 'কার্ট দেখুন', onClick: () => setCartOpen(true) },
                })
              })
            }
          >
            <ShoppingCart data-icon="inline-start" />
            {outOfStock ? 'স্টক শেষ' : 'কার্টে যোগ করুন'}
          </Button>
        )}
        <Button
          variant="outline"
          size="icon-lg"
          aria-label={wished ? 'উইশলিস্ট থেকে সরান' : 'উইশলিস্টে যোগ করুন'}
          aria-pressed={wished}
          onClick={() =>
            requireLogin(() => {
              toggleWish(product.id, product)
              toast.success(wished ? 'উইশলিস্ট থেকে সরানো হয়েছে' : 'উইশলিস্টে যোগ হয়েছে')
            })
          }
        >
          <Heart className={cn(wished && 'fill-destructive text-destructive')} />
        </Button>
      </div>
      {line && (
        <Button variant="ghost" size="sm" className="w-fit text-muted-foreground" onClick={() => remove(product.id, pack.id)}>
          কার্ট থেকে সরান
        </Button>
      )}
    </div>
  )
}
