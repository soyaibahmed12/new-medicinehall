'use client'

import { Minus, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { MAX_QTY_PER_LINE } from '@/lib/store'
import { cn } from '@/lib/utils'

export function QuantityStepper({
  value,
  onChange,
  max = MAX_QTY_PER_LINE,
  size = 'default',
  className,
}: {
  value: number
  onChange: (v: number) => void
  max?: number
  size?: 'sm' | 'default'
  className?: string
}) {
  const btn = size === 'sm' ? 'icon-sm' : 'icon'
  return (
    <div className={cn('inline-flex items-center rounded-full border bg-card p-0.5', className)}>
      <Button
        variant="ghost"
        size={btn}
        className="rounded-full"
        aria-label="পরিমাণ কমান"
        disabled={value <= 1}
        onClick={() => onChange(value - 1)}
      >
        <Minus />
      </Button>
      <span className={cn('min-w-8 text-center font-semibold tabular-nums', size === 'sm' ? 'text-sm' : 'text-base')} aria-live="polite">
        {value.toLocaleString('bn-BD')}
      </span>
      <Button
        variant="ghost"
        size={btn}
        className="rounded-full"
        aria-label="পরিমাণ বাড়ান"
        disabled={value >= max}
        onClick={() => onChange(value + 1)}
      >
        <Plus />
      </Button>
    </div>
  )
}
