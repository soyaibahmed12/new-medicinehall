'use client'

import Image from 'next/image'
import Link from 'next/link'
import { FileText, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { QuantityStepper } from '@/components/cart/quantity-stepper'
import { formatTaka } from '@/lib/catalog'
import { resolveCart, useShop } from '@/lib/store'

type Line = ReturnType<typeof resolveCart>['lines'][number]

export function CartLineItem({ line, compact }: { line: Line; compact?: boolean }) {
  const setQty = useShop((s) => s.setQty)
  const remove = useShop((s) => s.remove)
  const { product, pack } = line

  return (
    <li className="flex gap-3 py-4">
      <Link
        href={`/product/${product.slug}`}
        className="relative size-20 shrink-0 overflow-hidden rounded-xl border bg-muted sm:size-24"
      >
        <Image src={product.image} alt={product.name} fill sizes="96px" className="object-contain p-1" />
      </Link>
      <div className="flex min-w-0 flex-1 flex-col gap-1">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <Link href={`/product/${product.slug}`} className="line-clamp-1 font-semibold hover:text-primary">
              {product.name} {product.strength}
            </Link>
            <p className="truncate text-xs text-muted-foreground">
              {product.generic} · {pack.label}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label={`${product.name} সরান`}
            onClick={() => remove(product.id, pack.id)}
          >
            <Trash2 />
          </Button>
        </div>
        {product.rx && (
          <Badge variant="outline" className="w-fit gap-1 text-[11px]">
            <FileText aria-hidden="true" /> প্রেসক্রিপশন প্রয়োজন
          </Badge>
        )}
        <div className="mt-auto flex items-center justify-between gap-2">
          <QuantityStepper
            size="sm"
            value={line.qty}
            max={Math.min(20, product.stock)}
            onChange={(q) => setQty(product.id, pack.id, q)}
          />
          <div className="text-right">
            <p className="font-bold text-primary">{formatTaka(line.total)}</p>
            {!compact && line.mrpTotal > line.total && (
              <p className="text-xs text-muted-foreground line-through">{formatTaka(line.mrpTotal)}</p>
            )}
          </div>
        </div>
      </div>
    </li>
  )
}
