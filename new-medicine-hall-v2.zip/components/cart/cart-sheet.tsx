'use client'

import Link from 'next/link'
import { ShoppingBag } from 'lucide-react'
import { Sheet, SheetContent, SheetFooter, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty'
import { Progress } from '@/components/ui/progress'
import { CartLineItem } from '@/components/cart/cart-line-item'
import { DELIVERY, bn, formatTaka } from '@/lib/catalog'
import { resolveCart, useShop } from '@/lib/store'

export function FreeDeliveryMeter({ subtotal }: { subtotal: number }) {
  const left = DELIVERY.freeOver - subtotal
  return (
    <div className="rounded-xl bg-secondary p-3">
      <p className="mb-2 text-xs font-medium text-secondary-foreground">
        {left > 0 ? (
          <>
            আরও <strong>{formatTaka(left)}</strong> এর কেনাকাটায় ফ্রি ডেলিভারি পাবেন!
          </>
        ) : (
          <>অভিনন্দন! আপনি ফ্রি ডেলিভারি পাচ্ছেন</>
        )}
      </p>
      <Progress value={Math.min(100, (subtotal / DELIVERY.freeOver) * 100)} aria-label="ফ্রি ডেলিভারি অগ্রগতি" />
    </div>
  )
}

export function CartSheet() {
  const open = useShop((s) => s.cartOpen)
  const setOpen = useShop((s) => s.setCartOpen)
  const cart = useShop((s) => s.cart)
  const { lines, subtotal, savings, count } = resolveCart(cart)

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent side="right" className="flex w-full flex-col gap-0 sm:max-w-md">
        <SheetHeader className="border-b">
          <SheetTitle className="flex items-center gap-2">
            <ShoppingBag className="size-5 text-primary" aria-hidden="true" /> আমার কার্ট ({bn(count)} টি আইটেম)
          </SheetTitle>
        </SheetHeader>

        {lines.length === 0 ? (
          <Empty className="flex-1">
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <ShoppingBag />
              </EmptyMedia>
              <EmptyTitle>আপনার কার্ট খালি</EmptyTitle>
              <EmptyDescription>প্রয়োজনীয় ঔষধ কার্টে যোগ করুন অথবা প্রেসক্রিপশন আপলোড করুন।</EmptyDescription>
            </EmptyHeader>
            <EmptyContent>
              <Button nativeButton={false} render={<Link href="/products" onClick={() => setOpen(false)} />}>
                কেনাকাটা শুরু করুন
              </Button>
            </EmptyContent>
          </Empty>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-4">
              <div className="py-3">
                <FreeDeliveryMeter subtotal={subtotal} />
              </div>
              <ul className="flex flex-col divide-y">
                {lines.map((l) => (
                  <CartLineItem key={`${l.productId}-${l.packId}`} line={l} compact />
                ))}
              </ul>
            </div>
            <SheetFooter className="border-t bg-muted/40">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">সাবটোটাল</span>
                <span className="text-lg font-bold">{formatTaka(subtotal)}</span>
              </div>
              {savings > 0 && (
                <p className="text-right text-xs font-medium text-chart-5">আপনি সাশ্রয় করছেন {formatTaka(savings)}</p>
              )}
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant="outline"
                  size="lg"
                  nativeButton={false}
                  render={<Link href="/cart" onClick={() => setOpen(false)} />}
                >
                  কার্ট দেখুন
                </Button>
                <Button size="lg" nativeButton={false} render={<Link href="/checkout" onClick={() => setOpen(false)} />}>
                  চেকআউট
                </Button>
              </div>
            </SheetFooter>
          </>
        )}
      </SheetContent>
    </Sheet>
  )
}
