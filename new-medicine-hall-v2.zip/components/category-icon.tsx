import {
  Baby,
  Citrus,
  Droplet,
  Eye,
  Flame,
  HandHeart,
  HeartPulse,
  Leaf,
  Pill,
  Sparkles,
  Stethoscope,
  Wind,
  type LucideIcon,
} from 'lucide-react'

const map: Record<string, LucideIcon> = {
  pill: Pill,
  droplet: Droplet,
  'heart-pulse': HeartPulse,
  citrus: Citrus,
  wind: Wind,
  flame: Flame,
  eye: Eye,
  sparkles: Sparkles,
  baby: Baby,
  stethoscope: Stethoscope,
  'hand-heart': HandHeart,
  leaf: Leaf,
}

export function CategoryIcon({ name, className }: { name: string; className?: string }) {
  const Icon = map[name] ?? Pill
  return <Icon className={className} aria-hidden="true" />
}
