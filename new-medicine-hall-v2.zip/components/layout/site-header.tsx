'use client'

import Link from 'next/link'
import { useTheme } from 'next-themes'
import {
  Download,
  LayoutDashboard,
  LogIn,
  LogOut,
  Store,
  UserPlus,
  Heart,
  LayoutGrid,
  MapPin,
  Menu,
  Moon,
  Package,
  PhoneCall,
  ShoppingCart,
  Sun,
  Truck,
  User,
  Zap,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { Separator } from '@/components/ui/separator'
import { Logo } from '@/components/layout/logo'
import { SearchBar } from '@/components/layout/search-bar'
import { CategoryIcon } from '@/components/category-icon'
import { categories } from '@/lib/catalog'
import { resolveCart, useShop } from '@/lib/store'
import { usePwaInstall } from '@/hooks/use-pwa-install'
import { logoutAction } from '@/lib/actions/auth'

export type HeaderUser = { fullName: string; email: string; role: 'user' | 'seller' | 'admin' } | null

function RoleLinks({ user, className }: { user: NonNullable<HeaderUser>; className?: string }) {
  return (
    <>
      {user.role === 'admin' && (
        <Link href="/admin" className={className}>
          <LayoutDashboard className="size-4" aria-hidden="true" /> অ্যাডমিন প্যানেল
        </Link>
      )}
      {(user.role === 'seller' || user.role === 'admin') && (
        <Link href="/seller" className={className}>
          <Store className="size-4" aria-hidden="true" /> সেলার প্যানেল
        </Link>
      )}
    </>
  )
}

function CountBadge({ n }: { n: number }) {
  if (!n) return null
  return (
    <span className="absolute -top-1 -right-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-deal px-1 text-[11px] font-bold text-deal-foreground">
      {n > 99 ? '99+' : n.toLocaleString('bn-BD')}
    </span>
  )
}

function ThemeToggle() {
  const { resolvedTheme, setTheme } = useTheme()
  return (
    <button
      type="button"
      onClick={() => setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')}
      className="flex items-center gap-1 hover:text-background"
      aria-label="থিম পরিবর্তন"
    >
      <Sun className="size-3.5 dark:hidden" aria-hidden="true" />
      <Moon className="hidden size-3.5 dark:block" aria-hidden="true" />
      <span className="dark:hidden">ডার্ক মোড</span>
      <span className="hidden dark:inline">লাইট মোড</span>
    </button>
  )
}

export function SiteHeader({ user }: { user: HeaderUser }) {
  const cart = useShop((s) => s.cart)
  const wishlist = useShop((s) => s.wishlist)
  const hydrated = useShop((s) => s.hydrated)
  const setCartOpen = useShop((s) => s.setCartOpen)
  const { count } = resolveCart(cart)
  const { install, installed } = usePwaInstall()

  return (
    <header className="sticky top-0 z-40 bg-background/90 backdrop-blur-lg supports-backdrop-filter:bg-background/75">
      <div className="hidden bg-foreground text-background/80 md:block">
        <div className="mx-auto flex h-9 max-w-7xl items-center justify-between px-4 text-xs">
          <div className="flex items-center gap-5">
            <span className="flex items-center gap-1.5">
              <PhoneCall className="size-3.5" aria-hidden="true" /> হটলাইন: ০৯৬১২-৩৪৫৬৭৮ (সকাল ৮টা - রাত ১২টা)
            </span>
            <span className="flex items-center gap-1.5">
              <Truck className="size-3.5" aria-hidden="true" /> ৬৪ জেলায় হোম ডেলিভারি
            </span>
          </div>
          <div className="flex items-center gap-5">
            <Link href="/track-order" className="flex items-center gap-1 hover:text-background">
              <Package className="size-3.5" aria-hidden="true" /> অর্ডার ট্র্যাক
            </Link>
            {!installed && (
              <button type="button" onClick={install} className="flex items-center gap-1 hover:text-background">
                <Download className="size-3.5" aria-hidden="true" /> অ্যাপ ইনস্টল
              </button>
            )}
            <ThemeToggle />
          </div>
        </div>
      </div>

      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 lg:gap-6">
        <Sheet>
          <SheetTrigger
            render={<Button variant="ghost" size="icon-lg" className="lg:hidden" aria-label="মেনু খুলুন" />}
          >
            <Menu />
          </SheetTrigger>
          <SheetContent side="left" className="w-80 overflow-y-auto">
            <SheetHeader>
              <SheetTitle className="sr-only">মেনু</SheetTitle>
              <Logo />
            </SheetHeader>
            <nav aria-label="ক্যাটাগরি" className="flex flex-col gap-1 px-4 pb-6">
              <p className="px-2 pb-1 text-xs font-semibold text-muted-foreground">ক্যাটাগরি</p>
              {categories.map((c) => (
                <Link
                  key={c.slug}
                  href={`/products?category=${c.slug}`}
                  className="flex items-center gap-3 rounded-xl px-2 py-2 text-sm font-medium hover:bg-muted"
                >
                  <span className={`flex size-8 items-center justify-center rounded-lg ${c.tint}`}>
                    <CategoryIcon name={c.icon} className="size-4" />
                  </span>
                  {c.name}
                </Link>
              ))}
              <Separator className="my-3" />
              {user ? (
                <>
                  <p className="px-2 pt-1 text-xs font-semibold text-muted-foreground">{user.fullName || user.email}</p>
                  <Link href="/account" className="flex items-center gap-2 rounded-xl px-2 py-2 text-sm font-medium hover:bg-muted">
                    <User className="size-4" aria-hidden="true" /> আমার প্রোফাইল
                  </Link>
                  <RoleLinks user={user} className="flex items-center gap-2 rounded-xl px-2 py-2 text-sm font-medium hover:bg-muted" />
                  <form action={logoutAction}>
                    <button type="submit" className="flex w-full items-center gap-2 rounded-xl px-2 py-2 text-left text-sm font-medium text-destructive hover:bg-muted">
                      <LogOut className="size-4" aria-hidden="true" /> লগআউট
                    </button>
                  </form>
                </>
              ) : (
                <>
                  <Link href="/login" className="flex items-center gap-2 rounded-xl px-2 py-2 text-sm font-medium hover:bg-muted">
                    <LogIn className="size-4" aria-hidden="true" /> লগইন
                  </Link>
                  <Link href="/register" className="flex items-center gap-2 rounded-xl px-2 py-2 text-sm font-medium hover:bg-muted">
                    <UserPlus className="size-4" aria-hidden="true" /> রেজিস্ট্রেশন
                  </Link>
                </>
              )}
              <Link href="/track-order" className="rounded-xl px-2 py-2 text-sm font-medium hover:bg-muted">
                অর্ডার ট্র্যাক করুন
              </Link>
              <Link href="/wishlist" className="rounded-xl px-2 py-2 text-sm font-medium hover:bg-muted">
                উইশলিস্ট
              </Link>
              <button
                type="button"
                onClick={install}
                className="rounded-xl px-2 py-2 text-left text-sm font-medium hover:bg-muted"
              >
                অ্যাপ ইনস্টল করুন
              </button>
            </nav>
          </SheetContent>
        </Sheet>

        <Logo />

        <SearchBar className="hidden flex-1 md:block" />

        <div className="ml-auto flex items-center gap-1 md:ml-0">
          {user ? (
            <>
              {(user.role === 'admin' || user.role === 'seller') && (
                <Button
                  variant="secondary"
                  className="hidden h-10 rounded-full px-4 xl:inline-flex"
                  nativeButton={false}
                  render={<Link href={user.role === 'admin' ? '/admin' : '/seller'} />}
                >
                  <LayoutDashboard data-icon="inline-start" />
                  {user.role === 'admin' ? 'অ্যাডমিন প্যানেল' : 'সেলার প্যানেল'}
                </Button>
              )}
            </>
          ) : (
            <>
              <Button variant="ghost" className="h-9 rounded-full px-2.5 text-xs sm:h-10 sm:px-4 sm:text-sm" nativeButton={false} render={<Link href="/login" />}>
                <LogIn data-icon="inline-start" className="hidden sm:block" /> লগইন
              </Button>
              <Button variant="outline" className="h-9 rounded-full px-2.5 text-xs sm:h-10 sm:px-4 sm:text-sm" nativeButton={false} render={<Link href="/register" />}>
                রেজিস্ট্রেশন
              </Button>
            </>
          )}
          <Button
            variant="ghost"
            size="icon-lg"
            className="relative hidden rounded-full sm:inline-flex"
            aria-label="উইশলিস্ট"
            nativeButton={false}
            render={<Link href="/wishlist" />}
          >
            <Heart />
            {hydrated && <CountBadge n={wishlist.length} />}
          </Button>
          {user && <Button
            variant="ghost"
            size="icon-lg"
            className="relative hidden rounded-full sm:inline-flex"
            aria-label="আমার প্রোফাইল"
            nativeButton={false}
            render={<Link href="/account" />}
          >
            <User />
          </Button>}
          <Button
            variant="default"
            className="relative h-10 rounded-full px-3 sm:px-4"
            onClick={() => setCartOpen(true)}
            aria-label="কার্ট দেখুন"
          >
            <ShoppingCart data-icon="inline-start" />
            <span className="hidden sm:inline">কার্ট</span>
            {hydrated && <CountBadge n={count} />}
          </Button>
        </div>
      </div>

      <div className="px-4 pb-3 md:hidden">
        <SearchBar />
      </div>

      <div className="hidden border-y bg-card lg:block">
        <nav aria-label="প্রধান নেভিগেশন" className="mx-auto flex h-11 max-w-7xl items-center gap-1 px-4">
          <Link
            href="/products"
            className="mr-2 flex h-full items-center gap-2 bg-primary px-4 text-sm font-semibold text-primary-foreground"
          >
            <LayoutGrid className="size-4" aria-hidden="true" /> সকল ক্যাটাগরি
          </Link>
          <div className="no-scrollbar flex flex-1 items-center gap-1 overflow-x-auto">
            {categories.slice(0, 8).map((c) => (
              <Link
                key={c.slug}
                href={`/products?category=${c.slug}`}
                className="flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              >
                <CategoryIcon name={c.icon} className="size-4" />
                {c.name}
              </Link>
            ))}
          </div>
          <Link href="/products?deal=flash" className="flex shrink-0 items-center gap-1.5 text-sm font-semibold">
            <Badge className="gap-1 bg-deal text-deal-foreground">
              <Zap aria-hidden="true" /> ফ্ল্যাশ সেল
            </Badge>
          </Link>
          <span className="ml-3 hidden shrink-0 items-center gap-1 text-xs text-muted-foreground xl:flex">
            <MapPin className="size-3.5" aria-hidden="true" /> ঢাকা, বাংলাদেশ
          </span>
        </nav>
      </div>
    </header>
  )
}
