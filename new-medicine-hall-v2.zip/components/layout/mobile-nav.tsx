'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Heart, House, LayoutGrid, LogIn, ShoppingCart, User } from 'lucide-react'
import { resolveCart, useShop } from '@/lib/store'
import { cn } from '@/lib/utils'

export function MobileNav({ loggedIn }: { loggedIn: boolean }) {
  const pathname = usePathname()
  const cart = useShop((s) => s.cart)
  const hydrated = useShop((s) => s.hydrated)
  const setCartOpen = useShop((s) => s.setCartOpen)
  const { count } = resolveCart(cart)

  const items = [
    { href: '/', label: 'হোম', icon: House },
    { href: '/products', label: 'ক্যাটাগরি', icon: LayoutGrid },
    { href: '/wishlist', label: 'উইশলিস্ট', icon: Heart },
    loggedIn ? { href: '/account', label: 'প্রোফাইল', icon: User } : { href: '/login', label: 'লগইন', icon: LogIn, featured: true },
  ]

  return (
    <nav
      aria-label="মোবাইল নেভিগেশন"
      className="fixed inset-x-0 bottom-0 z-40 border-t bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-lg lg:hidden"
    >
      <ul className="grid grid-cols-5">
        {items.map(({ href, label, icon: Icon, featured }) => {
          const active = pathname === href
          return (
            <li key={href}>
              <Link
                href={href}
                className={cn(
                  'flex flex-col items-center gap-0.5 py-2 text-[11px] font-medium text-muted-foreground',
                  active && 'text-primary',
                )}
              >
                {featured ? (
                  <span className="-mt-6 flex size-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg ring-4 ring-background">
                    <Icon className="size-5" aria-hidden="true" />
                  </span>
                ) : (
                  <Icon className="size-5" aria-hidden="true" />
                )}
                {label}
              </Link>
            </li>
          )
        })}
        <li>
          <button
            type="button"
            onClick={() => setCartOpen(true)}
            className="relative flex w-full flex-col items-center gap-0.5 py-2 text-[11px] font-medium text-muted-foreground"
          >
            <span className="relative">
              <ShoppingCart className="size-5" aria-hidden="true" />
              {hydrated && count > 0 && (
                <span className="absolute -top-2 -right-2.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-deal px-1 text-[10px] font-bold text-deal-foreground">
                  {count.toLocaleString('bn-BD')}
                </span>
              )}
            </span>
            কার্ট
          </button>
        </li>
      </ul>
    </nav>
  )
}
