'use client'

import { useEffect, useState } from 'react'
import { ArrowUp, Headset, MessageCircle, PhoneCall } from 'lucide-react'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function FloatingHelp() {
  const [showTop, setShowTop] = useState(false)

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 600)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <div className="fixed right-4 bottom-24 z-30 flex flex-col items-end gap-2 lg:bottom-6">
      <Button
        variant="outline"
        size="icon-lg"
        aria-label="উপরে যান"
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className={cn(
          'rounded-full shadow-md transition-all',
          showTop ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-2 opacity-0',
        )}
      >
        <ArrowUp />
      </Button>
      <Popover>
        <PopoverTrigger
          render={
            <Button size="icon-lg" className="size-12 rounded-full shadow-lg" aria-label="সাহায্য দরকার?" />
          }
        >
          <Headset />
        </PopoverTrigger>
        <PopoverContent side="top" align="end" className="w-72">
          <p className="font-semibold">ফার্মাসিস্টের সাথে কথা বলুন</p>
          <p className="text-sm text-muted-foreground">
            ঔষধ সংক্রান্ত যেকোনো প্রশ্নে আমাদের রেজিস্টার্ড ফার্মাসিস্ট সাহায্য করবেন।
          </p>
          <div className="mt-2 flex flex-col gap-2">
            <Button nativeButton={false} render={<a href="tel:+8809612345678" />}>
              <PhoneCall data-icon="inline-start" /> কল করুন: ০৯৬১২-৩৪৫৬৭৮
            </Button>
            <Button
              variant="outline"
              nativeButton={false}
              render={<a href="https://wa.me/8801700000000" target="_blank" rel="noreferrer" />}
            >
              <MessageCircle data-icon="inline-start" /> হোয়াটসঅ্যাপে মেসেজ
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
