'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Mic, Search, TrendingUp } from 'lucide-react'
import { toast } from 'sonner'
import { InputGroup, InputGroupAddon, InputGroupButton, InputGroupInput } from '@/components/ui/input-group'
import { formatTaka } from '@/lib/catalog'
import { searchProductsAction } from '@/lib/actions/orders'
import { cn } from '@/lib/utils'

const trending = ['Napa', 'Seclo', 'Fexo', 'Insulin', 'BP Monitor', 'Vitamin C']

type SpeechRecognitionLike = {
  lang: string
  interimResults: boolean
  onresult: (e: { results: { 0: { 0: { transcript: string } } } }) => void
  onend: () => void
  onerror: () => void
  start: () => void
}

export function SearchBar({ className }: { className?: string }) {
  const router = useRouter()
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState(-1)
  const [listening, setListening] = useState(false)
  const blurTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const [results, setResults] = useState<Awaited<ReturnType<typeof searchProductsAction>>>([])

  useEffect(() => {
    const term = q.trim()
    if (term.length < 2) {
      setResults([])
      return
    }
    let cancelled = false
    const t = setTimeout(() => {
      searchProductsAction(term).then((r) => !cancelled && setResults(r))
    }, 250)
    return () => {
      cancelled = true
      clearTimeout(t)
    }
  }, [q])

  const submit = (term = q) => {
    const t = term.trim()
    setOpen(false)
    router.push(t ? `/products?q=${encodeURIComponent(t)}` : '/products')
  }

  const startVoice = () => {
    const w = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike
      webkitSpeechRecognition?: new () => SpeechRecognitionLike
    }
    const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition
    if (!Ctor) {
      toast.error('আপনার ব্রাউজারে ভয়েস সার্চ সাপোর্ট করে না')
      return
    }
    const rec = new Ctor()
    rec.lang = 'bn-BD'
    rec.interimResults = false
    rec.onresult = (e) => {
      const text = e.results[0][0].transcript
      setQ(text)
      submit(text)
    }
    rec.onend = () => setListening(false)
    rec.onerror = () => setListening(false)
    setListening(true)
    rec.start()
  }

  return (
    <div className={cn('relative w-full', className)}>
      <form
        role="search"
        onSubmit={(e) => {
          e.preventDefault()
          if (active >= 0 && results[active]) {
            setOpen(false)
            router.push(`/product/${results[active].slug}`)
            return
          }
          submit()
        }}
      >
        <InputGroup className="h-11 rounded-full bg-card shadow-sm">
          <InputGroupAddon>
            <Search aria-hidden="true" />
          </InputGroupAddon>
          <InputGroupInput
            type="search"
            aria-label="ঔষধ খুঁজুন"
            placeholder="ঔষধ, জেনেরিক নাম বা কোম্পানি দিয়ে খুঁজুন..."
            value={q}
            onChange={(e) => {
              setQ(e.target.value)
              setActive(-1)
              setOpen(true)
            }}
            onFocus={() => setOpen(true)}
            onBlur={() => {
              blurTimer.current = setTimeout(() => setOpen(false), 150)
            }}
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown') {
                e.preventDefault()
                setActive((a) => Math.min(a + 1, results.length - 1))
              } else if (e.key === 'ArrowUp') {
                e.preventDefault()
                setActive((a) => Math.max(a - 1, -1))
              } else if (e.key === 'Escape') {
                setOpen(false)
              }
            }}
            autoComplete="off"
          />
          <InputGroupAddon align="inline-end" className="gap-1">
            <InputGroupButton
              type="button"
              size="icon-sm"
              variant="ghost"
              aria-label="ভয়েস সার্চ"
              onClick={startVoice}
              className={cn('rounded-full', listening && 'animate-pulse text-deal')}
            >
              <Mic />
            </InputGroupButton>
            <InputGroupButton type="submit" size="sm" variant="default" className="rounded-full px-4">
              খুঁজুন
            </InputGroupButton>
          </InputGroupAddon>
        </InputGroup>
      </form>

      {open && (
        <div
          className="absolute inset-x-0 top-full z-50 mt-2 overflow-hidden rounded-2xl border bg-popover p-2 text-popover-foreground shadow-xl"
          onMouseDown={() => blurTimer.current && clearTimeout(blurTimer.current)}
        >
          {results.length > 0 ? (
            <ul role="listbox" aria-label="সার্চ সাজেশন" className="flex flex-col">
              {results.map((p, i) => (
                <li key={p.id} role="option" aria-selected={i === active}>
                  <Link
                    href={`/product/${p.slug}`}
                    onClick={() => setOpen(false)}
                    className={cn(
                      'flex items-center gap-3 rounded-xl p-2 transition-colors hover:bg-muted',
                      i === active && 'bg-muted',
                    )}
                  >
                    <Image src={p.image} alt="" width={44} height={44} className="rounded-lg bg-muted object-contain" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">
                        {p.name} <span className="font-normal text-muted-foreground">{p.strength}</span>
                      </p>
                      <p className="truncate text-xs text-muted-foreground">
                        {p.generic}
                      </p>
                    </div>
                    <span className="text-sm font-semibold text-primary">{formatTaka(p.price)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          ) : q.trim() ? (
            <p className="p-3 text-sm text-muted-foreground">
              {'"'}
              {q}
              {'"'} এর জন্য কিছু পাওয়া যায়নি। প্রেসক্রিপশন আপলোড করুন, আমরা খুঁজে দেব।
            </p>
          ) : (
            <div className="p-2">
              <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <TrendingUp className="size-3.5" aria-hidden="true" /> জনপ্রিয় সার্চ
              </p>
              <div className="flex flex-wrap gap-2">
                {trending.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => {
                      setQ(t)
                      submit(t)
                    }}
                    className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
