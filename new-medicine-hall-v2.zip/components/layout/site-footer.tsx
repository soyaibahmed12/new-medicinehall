import Link from 'next/link'
import { Banknote, CreditCard, Mail, MapPin, PhoneCall, ShieldCheck, Smartphone, Wallet } from 'lucide-react'
import { Logo } from '@/components/layout/logo'
import { categories } from '@/lib/catalog'

const payments = [
  { label: 'বিকাশ', icon: Smartphone },
  { label: 'নগদ', icon: Wallet },
  { label: 'রকেট', icon: Smartphone },
  { label: 'কার্ড', icon: CreditCard },
  { label: 'ক্যাশ অন ডেলিভারি', icon: Banknote },
]

export function SiteFooter() {
  return (
    <footer className="mt-16 bg-foreground text-background/75">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:grid-cols-2 lg:grid-cols-5">
        <div className="flex flex-col gap-4 lg:col-span-2">
          <Logo inverted />
          <p className="max-w-sm text-sm leading-relaxed">
            DGDA অনুমোদিত লাইসেন্সপ্রাপ্ত অনলাইন ফার্মেসি। সরাসরি কোম্পানি ও অনুমোদিত ডিস্ট্রিবিউটর থেকে সংগৃহীত
            ১০০% আসল ঔষধ, সারা বাংলাদেশে দ্রুত ডেলিভারি।
          </p>
          <ul className="flex flex-col gap-2 text-sm">
            <li className="flex items-center gap-2">
              <MapPin className="size-4 shrink-0" aria-hidden="true" /> ৪২/এ, মিরপুর রোড, ধানমন্ডি, ঢাকা-১২০৫
            </li>
            <li className="flex items-center gap-2">
              <PhoneCall className="size-4 shrink-0" aria-hidden="true" /> ০৯৬১২-৩৪৫৬৭৮
            </li>
            <li className="flex items-center gap-2">
              <Mail className="size-4 shrink-0" aria-hidden="true" /> support@newmedicinehall.com
            </li>
            <li className="flex items-center gap-2">
              <ShieldCheck className="size-4 shrink-0" aria-hidden="true" /> ড্রাগ লাইসেন্স: DL-0012345/2026
            </li>
          </ul>
        </div>

        <div>
          <h2 className="mb-4 font-semibold text-background">ক্যাটাগরি</h2>
          <ul className="flex flex-col gap-2 text-sm">
            {categories.slice(0, 6).map((c) => (
              <li key={c.slug}>
                <Link href={`/products?category=${c.slug}`} className="hover:text-background">
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="mb-4 font-semibold text-background">সহায়তা</h2>
          <ul className="flex flex-col gap-2 text-sm">
            <li><Link href="/track-order" className="hover:text-background">অর্ডার ট্র্যাক করুন</Link></li>
            <li><Link href="/cart" className="hover:text-background">আমার কার্ট</Link></li>
            <li><Link href="/wishlist" className="hover:text-background">উইশলিস্ট</Link></li>
            <li><Link href="/#faq" className="hover:text-background">সাধারণ জিজ্ঞাসা</Link></li>
          </ul>
        </div>

        <div>
          <h2 className="mb-4 font-semibold text-background">নীতিমালা</h2>
          <ul className="flex flex-col gap-2 text-sm">
            <li><Link href="/#faq" className="hover:text-background">রিটার্ন ও রিফান্ড</Link></li>
            <li><Link href="/#faq" className="hover:text-background">ডেলিভারি পলিসি</Link></li>
            <li><Link href="/#faq" className="hover:text-background">প্রাইভেসি পলিসি</Link></li>
            <li><Link href="/#faq" className="hover:text-background">শর্তাবলী</Link></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-background/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 py-6 text-xs md:flex-row">
          <p>© ২০২৬ New Medicine Hall. সর্বস্বত্ব সংরক্ষিত।</p>
          <ul className="flex flex-wrap items-center justify-center gap-2" aria-label="পেমেন্ট পদ্ধতি">
            {payments.map(({ label, icon: Icon }) => (
              <li
                key={label}
                className="flex items-center gap-1.5 rounded-md bg-background/10 px-2.5 py-1.5 font-medium text-background"
              >
                <Icon className="size-3.5" aria-hidden="true" /> {label}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </footer>
  )
}
