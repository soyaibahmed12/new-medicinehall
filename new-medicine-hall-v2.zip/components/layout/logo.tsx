import Image from 'next/image'
import Link from 'next/link'
import { cn } from '@/lib/utils'

export function Logo({ className, inverted }: { className?: string; inverted?: boolean }) {
  return (
    <Link href="/" className={cn('flex shrink-0 items-center gap-2.5', className)} aria-label="New Medicine Hall হোম">
      <Image src="/icons/nmh-192.png" alt="" width={40} height={40} className="size-10 rounded-xl" priority />
      <span className="flex flex-col leading-none">
        <span className={cn('text-lg font-bold tracking-tight', inverted ? 'text-background' : 'text-foreground')}>
          New Medicine <span className={inverted ? 'text-background' : 'text-primary'}>Hall</span>
        </span>
        <span className={cn('text-[11px] font-medium', inverted ? 'text-background/70' : 'text-muted-foreground')}>
          বিশ্বস্ত অনলাইন ফার্মেসি
        </span>
      </span>
    </Link>
  )
}
