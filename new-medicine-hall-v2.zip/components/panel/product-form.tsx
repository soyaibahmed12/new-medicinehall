'use client'

import { useActionState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { ImageUpload } from '@/components/panel/image-upload'
import { categories, medicineTypes } from '@/lib/catalog'
import { saveProductAction } from '@/lib/actions/products'
import type { FormState } from '@/lib/actions/auth'

export type ProductFormValues = {
  id?: string
  name?: string
  generic?: string
  strength?: string
  form?: string
  company?: string
  category?: string
  medicine_type?: string
  image_url?: string | null
  price?: number
  mrp?: number
  stock?: number
  description?: string
  uses?: string[]
  dosage?: string
  side_effects?: string[]
  warnings?: string
  status?: string
  tags?: string[]
}

const selectCls = 'h-10 w-full rounded-lg border bg-background px-3 text-sm'

function Field({ label, htmlFor, children }: { label: string; htmlFor: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
    </div>
  )
}

export function ProductForm({ values = {}, isAdmin }: { values?: ProductFormValues; isAdmin: boolean }) {
  const [state, action, pending] = useActionState<FormState, FormData>(saveProductAction, undefined)
  return (
    <form action={action} className="grid gap-6 lg:grid-cols-3">
      {values.id && <input type="hidden" name="id" value={values.id} />}
      <div className="rounded-2xl border bg-card p-4 lg:order-2">
        <h2 className="mb-3 font-semibold">পণ্যের ছবি</h2>
        <ImageUpload initial={values.image_url} />
      </div>

      <div className="flex flex-col gap-4 lg:order-1 lg:col-span-2">
        <div className="grid gap-4 rounded-2xl border bg-card p-4 sm:grid-cols-2">
          <Field label="পণ্যের নাম *" htmlFor="name"><Input id="name" name="name" required defaultValue={values.name} /></Field>
          <Field label="জেনেরিক / উপাদান" htmlFor="generic"><Input id="generic" name="generic" defaultValue={values.generic} /></Field>
          <Field label="পাওয়ার / সাইজ" htmlFor="strength"><Input id="strength" name="strength" placeholder="500 mg" defaultValue={values.strength} /></Field>
          <Field label="ফর্ম" htmlFor="form"><Input id="form" name="form" placeholder="ট্যাবলেট, সিরাপ…" defaultValue={values.form} /></Field>
          <Field label="কোম্পানি" htmlFor="company"><Input id="company" name="company" defaultValue={values.company} /></Field>
          <Field label="ঔষধের ধরন *" htmlFor="medicine_type">
            <select id="medicine_type" name="medicine_type" required defaultValue={values.medicine_type ?? 'allopathic'} className={selectCls}>
              {medicineTypes.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </Field>
          <Field label="ক্যাটাগরি *" htmlFor="category">
            <select id="category" name="category" required defaultValue={values.category ?? 'medicine'} className={selectCls}>
              {categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
            </select>
          </Field>
          <Field label="অবস্থা" htmlFor="status">
            <select id="status" name="status" defaultValue={values.status ?? 'active'} className={selectCls}>
              <option value="active">সাইটে দেখাবে</option>
              <option value="hidden">লুকানো</option>
            </select>
          </Field>
        </div>

        <div className="grid gap-4 rounded-2xl border bg-card p-4 sm:grid-cols-3">
          <Field label="বিক্রয়মূল্য (৳) *" htmlFor="price"><Input id="price" name="price" type="number" min={0} step="0.01" required defaultValue={values.price} /></Field>
          <Field label="MRP (৳) *" htmlFor="mrp"><Input id="mrp" name="mrp" type="number" min={0} step="0.01" required defaultValue={values.mrp} /></Field>
          <Field label="স্টক *" htmlFor="stock"><Input id="stock" name="stock" type="number" min={0} step="1" required defaultValue={values.stock ?? 0} /></Field>
        </div>

        <div className="grid gap-4 rounded-2xl border bg-card p-4">
          <Field label="বিবরণ" htmlFor="description"><Textarea id="description" name="description" rows={3} defaultValue={values.description} /></Field>
          <Field label="ব্যবহার (প্রতি লাইনে একটি)" htmlFor="uses"><Textarea id="uses" name="uses" rows={3} defaultValue={values.uses?.join('\n')} /></Field>
          <Field label="সেবনবিধি" htmlFor="dosage"><Textarea id="dosage" name="dosage" rows={2} defaultValue={values.dosage} /></Field>
          <Field label="পার্শ্বপ্রতিক্রিয়া (প্রতি লাইনে একটি)" htmlFor="side_effects"><Textarea id="side_effects" name="side_effects" rows={3} defaultValue={values.side_effects?.join('\n')} /></Field>
          <Field label="সতর্কতা" htmlFor="warnings"><Textarea id="warnings" name="warnings" rows={2} defaultValue={values.warnings} /></Field>
        </div>

        {isAdmin && (
          <fieldset className="flex flex-wrap gap-4 rounded-2xl border bg-card p-4 text-sm">
            <legend className="px-1 text-sm font-semibold">হোমপেজ ট্যাগ (শুধু অ্যাডমিন)</legend>
            {[['flash', 'ফ্ল্যাশ সেল'], ['bestseller', 'বেস্টসেলার'], ['trending', 'ট্রেন্ডিং'], ['new', 'নতুন']].map(([v, l]) => (
              <label key={v} className="flex items-center gap-2">
                <input type="checkbox" name="tags" value={v} defaultChecked={values.tags?.includes(v)} className="size-4 accent-[var(--primary)]" /> {l}
              </label>
            ))}
          </fieldset>
        )}

        {state?.error && <p role="alert" className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{state.error}</p>}
        <Button type="submit" size="lg" className="w-fit rounded-full px-8" disabled={pending}>
          {pending ? 'সংরক্ষণ হচ্ছে…' : values.id ? 'আপডেট করুন' : 'পণ্য যোগ করুন'}
        </Button>
      </div>
    </form>
  )
}
