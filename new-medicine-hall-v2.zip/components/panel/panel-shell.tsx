import Link from 'next/link'
import type { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

export type PanelLink = { href: string; label: string; icon: LucideIcon }

export function PanelShell({ title, links, children }: { title: string; links: PanelLink[]; children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold">{title}</h1>
        <nav aria-label={title} className="no-scrollbar flex gap-2 overflow-x-auto">
          {links.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={cn('flex shrink-0 items-center gap-1.5 rounded-full border bg-card px-4 py-2 text-sm font-medium transition-colors hover:border-primary hover:text-primary')}
            >
              <Icon className="size-4" aria-hidden="true" /> {label}
            </Link>
          ))}
        </nav>
      </div>
      {children}
    </div>
  )
}

export function StatCard({ label, value, icon: Icon, tint = 'bg-primary/10 text-primary' }: { label: string; value: string; icon: LucideIcon; tint?: string }) {
  return (
    <div className="flex items-center gap-4 rounded-2xl border bg-card p-4">
      <span className={cn('flex size-12 items-center justify-center rounded-xl', tint)}>
        <Icon className="size-6" aria-hidden="true" />
      </span>
      <div>
        <p className="text-2xl font-bold">{value}</p>
        <p className="text-sm text-muted-foreground">{label}</p>
      </div>
    </div>
  )
}
