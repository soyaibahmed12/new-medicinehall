'use client'

import { useRef, useState } from 'react'
import Image from 'next/image'
import { Camera, ImagePlus, Loader2, X } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { createClient } from '@/lib/supabase/client'

// Resize on the phone before uploading so big camera photos don't waste mobile data.
async function shrink(file: File, max = 1200): Promise<Blob> {
  const bmp = await createImageBitmap(file)
  const scale = Math.min(1, max / Math.max(bmp.width, bmp.height))
  const canvas = document.createElement('canvas')
  canvas.width = Math.round(bmp.width * scale)
  canvas.height = Math.round(bmp.height * scale)
  canvas.getContext('2d')!.drawImage(bmp, 0, 0, canvas.width, canvas.height)
  return new Promise((res, rej) => canvas.toBlob((b) => (b ? res(b) : rej(new Error('encode'))), 'image/jpeg', 0.85))
}

export function ImageUpload({ name = 'image_url', initial }: { name?: string; initial?: string | null }) {
  const [url, setUrl] = useState(initial ?? '')
  const [busy, setBusy] = useState(false)
  const cameraRef = useRef<HTMLInputElement>(null)
  const galleryRef = useRef<HTMLInputElement>(null)

  async function handle(file?: File) {
    if (!file) return
    if (!file.type.startsWith('image/')) return toast.error('শুধু ছবি আপলোড করা যাবে')
    setBusy(true)
    try {
      const supabase = createClient()
      const { data: auth } = await supabase.auth.getUser()
      if (!auth.user) throw new Error('login')
      const blob = await shrink(file)
      const path = `${auth.user.id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.jpg`
      const { error } = await supabase.storage.from('product-images').upload(path, blob, { contentType: 'image/jpeg', cacheControl: '31536000' })
      if (error) throw error
      setUrl(supabase.storage.from('product-images').getPublicUrl(path).data.publicUrl)
      toast.success('ছবি আপলোড হয়েছে')
    } catch {
      toast.error('ছবি আপলোড করা যায়নি, আবার চেষ্টা করুন')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <input type="hidden" name={name} value={url} />
      <div className="relative flex aspect-square w-full max-w-xs items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed bg-muted/50">
        {url ? (
          <>
            <Image src={url} alt="পণ্যের ছবি" fill sizes="320px" className="object-contain p-2" />
            <Button type="button" size="icon-sm" variant="secondary" className="absolute top-2 right-2 rounded-full" aria-label="ছবি সরান" onClick={() => setUrl('')}>
              <X />
            </Button>
          </>
        ) : (
          <span className="flex flex-col items-center gap-1 text-sm text-muted-foreground">
            {busy ? <Loader2 className="size-6 animate-spin" aria-hidden="true" /> : <ImagePlus className="size-6" aria-hidden="true" />}
            {busy ? 'আপলোড হচ্ছে…' : 'ছবি যোগ করুন'}
          </span>
        )}
      </div>
      <div className="flex flex-wrap gap-2">
        <Button type="button" variant="outline" disabled={busy} onClick={() => cameraRef.current?.click()}>
          <Camera data-icon="inline-start" /> ক্যামেরা দিয়ে তুলুন
        </Button>
        <Button type="button" variant="outline" disabled={busy} onClick={() => galleryRef.current?.click()}>
          <ImagePlus data-icon="inline-start" /> গ্যালারি থেকে নিন
        </Button>
      </div>
      <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => handle(e.target.files?.[0])} />
      <input ref={galleryRef} type="file" accept="image/*" className="hidden" onChange={(e) => handle(e.target.files?.[0])} />
    </div>
  )
}
