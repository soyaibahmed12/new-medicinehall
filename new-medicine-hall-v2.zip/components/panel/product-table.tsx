import Image from 'next/image'
import Link from 'next/link'
import { Eye, EyeOff, Pencil, Trash2 } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { formatTaka, medicineTypeLabel } from '@/lib/catalog'
import { deleteProductAction, toggleProductStatusAction } from '@/lib/actions/products'

type Row = {
  id: string
  name: string
  strength: string
  slug: string
  image_url: string | null
  price: number
  stock: number
  status: string
  medicine_type: string
  seller?: string
}

export function ProductTable({ rows, showSeller }: { rows: Row[]; showSeller?: boolean }) {
  if (!rows.length) return <p className="rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">এখনো কোনো পণ্য নেই।</p>
  return (
    <div className="overflow-x-auto rounded-2xl border bg-card">
      <table className="w-full text-sm">
        <thead className="text-left text-xs text-muted-foreground">
          <tr>
            <th className="p-3">পণ্য</th>
            <th className="p-3">ধরন</th>
            {showSeller && <th className="p-3">সেলার</th>}
            <th className="p-3">দাম</th>
            <th className="p-3">স্টক</th>
            <th className="p-3 text-right">অ্যাকশন</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id} className="border-t">
              <td className="p-3">
                <div className="flex items-center gap-3">
                  <Image src={r.image_url || '/products/placeholder.svg'} alt="" width={40} height={40} className="size-10 rounded-lg bg-muted object-contain" />
                  <div>
                    <Link href={`/product/${r.slug}`} className="font-medium hover:underline">{r.name} <span className="font-normal text-muted-foreground">{r.strength}</span></Link>
                    {r.status === 'hidden' && <Badge variant="outline" className="ml-2">লুকানো</Badge>}
                  </div>
                </div>
              </td>
              <td className="p-3">{medicineTypeLabel(r.medicine_type)}</td>
              {showSeller && <td className="p-3">{r.seller ?? '—'}</td>}
              <td className="p-3">{formatTaka(Number(r.price))}</td>
              <td className="p-3">{r.stock.toLocaleString('bn-BD')}</td>
              <td className="p-3">
                <div className="flex justify-end gap-1">
                  <Button size="icon-sm" variant="ghost" aria-label="সম্পাদনা" nativeButton={false} render={<Link href={`/seller/products/${r.id}/edit`} />}><Pencil /></Button>
                  <form action={toggleProductStatusAction}>
                    <input type="hidden" name="id" value={r.id} />
                    <input type="hidden" name="status" value={r.status} />
                    <Button size="icon-sm" variant="ghost" type="submit" aria-label={r.status === 'active' ? 'লুকান' : 'দেখান'}>{r.status === 'active' ? <EyeOff /> : <Eye />}</Button>
                  </form>
                  <form action={deleteProductAction}>
                    <input type="hidden" name="id" value={r.id} />
                    <Button size="icon-sm" variant="ghost" type="submit" aria-label="মুছুন" className="text-destructive"><Trash2 /></Button>
                  </form>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
