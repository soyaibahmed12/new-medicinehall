'use client'

import { createContext, useCallback, useContext } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { toast } from 'sonner'

const AuthCtx = createContext<{ loggedIn: boolean }>({ loggedIn: false })

export function AuthProvider({ loggedIn, children }: { loggedIn: boolean; children: React.ReactNode }) {
  return <AuthCtx.Provider value={{ loggedIn }}>{children}</AuthCtx.Provider>
}

/** Wrap any shopper action (add to cart, wishlist…). Guests are sent to login first. */
export function useRequireLogin() {
  const { loggedIn } = useContext(AuthCtx)
  const router = useRouter()
  const pathname = usePathname()
  return useCallback(
    (action: () => void) => {
      if (loggedIn) return action()
      toast.info('এই কাজটি করতে আগে লগইন করুন')
      router.push(`/login?next=${encodeURIComponent(pathname)}`)
    },
    [loggedIn, router, pathname],
  )
}
