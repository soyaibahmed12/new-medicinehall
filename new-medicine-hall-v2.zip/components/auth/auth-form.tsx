'use client'

import { useActionState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { loginAction, registerAction, type FormState } from '@/lib/actions/auth'

export function AuthForm({ mode, next }: { mode: 'login' | 'register'; next: string }) {
  const [state, action, pending] = useActionState<FormState, FormData>(mode === 'login' ? loginAction : registerAction, undefined)
  const isLogin = mode === 'login'
  return (
    <form action={action} className="flex flex-col gap-4">
      <input type="hidden" name="next" value={next} />
      {!isLogin && (
        <>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="full_name">পুরো নাম</Label>
            <Input id="full_name" name="full_name" required autoComplete="name" placeholder="আপনার নাম" />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="phone">মোবাইল নম্বর</Label>
            <Input id="phone" name="phone" type="tel" required inputMode="numeric" pattern="01[0-9]{9}" autoComplete="tel" placeholder="01XXXXXXXXX" />
          </div>
        </>
      )}
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="email">ইমেইল</Label>
        <Input id="email" name="email" type="email" required autoComplete="email" placeholder="you@example.com" />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="password">পাসওয়ার্ড</Label>
        <Input id="password" name="password" type="password" required minLength={isLogin ? 1 : 8} autoComplete={isLogin ? 'current-password' : 'new-password'} placeholder={isLogin ? '••••••••' : 'কমপক্ষে ৮ অক্ষর'} />
      </div>
      {state?.error && <p role="alert" className="rounded-lg bg-destructive/10 p-2.5 text-sm text-destructive">{state.error}</p>}
      {state?.message && <p role="status" className="rounded-lg bg-chart-5/10 p-2.5 text-sm text-chart-5">{state.message}</p>}
      <Button type="submit" size="lg" className="rounded-full" disabled={pending}>
        {pending ? 'অপেক্ষা করুন…' : isLogin ? 'লগইন করুন' : 'রেজিস্ট্রেশন করুন'}
      </Button>
      <p className="text-center text-sm text-muted-foreground">
        {isLogin ? 'নতুন গ্রাহক?' : 'আগেই অ্যাকাউন্ট আছে?'}{' '}
        <Link href={`${isLogin ? '/register' : '/login'}${next !== '/' ? `?next=${encodeURIComponent(next)}` : ''}`} className="font-semibold text-primary hover:underline">
          {isLogin ? 'রেজিস্ট্রেশন করুন' : 'লগইন করুন'}
        </Link>
      </p>
    </form>
  )
}
