# New Medicine Hall — Setup

## 1. Supabase (একবারের সেটআপ)
1. supabase.com এ নতুন প্রজেক্ট খুলুন।
2. **SQL Editor** এ `supabase/migrations/0001_init.sql` পুরোটা রান করুন।
3. **Authentication → Providers → Email** এ "Confirm email" বন্ধ করুন (ইচ্ছা হলে চালু রাখতে পারেন)।
4. **Project Settings → API** থেকে URL ও anon (publishable) key নিন।

## 2. Vercel Environment Variables
`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `NEXT_PUBLIC_SITE_URL` — তারপর Redeploy।

## 3. প্রথম অ্যাডমিন
সাইটে গিয়ে **সবার আগে আপনি নিজে রেজিস্ট্রেশন করুন** — প্রথম অ্যাকাউন্টটি স্বয়ংক্রিয়ভাবে **Admin** হয়।
এরপর সবাই সাধারণ গ্রাহক। শুধু অ্যাডমিন `/admin/users` থেকে কাউকে **Seller** বানাতে পারে।

## 4. (ঐচ্ছিক) স্টার্টার পণ্য
অ্যাডমিন হওয়ার পর SQL Editor এ `supabase/seed.sql` রান করুন।

## রোল নিয়ম
- Guest: দেখতে ও সার্চ করতে পারবে (Google ক্রল করতে পারে); কার্ট/উইশলিস্ট/অর্ডার করতে লগইন লাগবে।
- User: কেনাকাটা, অর্ডার, প্রোফাইল।
- Seller (শুধু অ্যাডমিন নিয়োগ দিলে): নিজের পণ্য যোগ/এডিট/মুছা; ছবি ফোনের ক্যামেরা/গ্যালারি থেকে সরাসরি Supabase Storage এ আপলোড।
- Admin: সব কিছু + সেলার নিয়োগ + অর্ডার স্ট্যাটাস।
