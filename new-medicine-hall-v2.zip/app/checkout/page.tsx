'use client'

import { useMemo, useState } from 'react'
import Link from 'next/link'
import { Banknote, CheckCircle2, CreditCard, Smartphone, Wallet } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { DELIVERY, formatTaka } from '@/lib/catalog'
import { resolveCart, useShop } from '@/lib/store'
import { placeOrderAction } from '@/lib/actions/orders'

type Zone = 'dhaka' | 'outside'
type PayMethod = 'bkash' | 'nagad' | 'rocket' | 'card' | 'cod'

const payOptions: { value: PayMethod; label: string; icon: typeof Smartphone }[] = [
  { value: 'bkash', label: 'বিকাশ', icon: Smartphone },
  { value: 'nagad', label: 'নগদ', icon: Wallet },
  { value: 'rocket', label: 'রকেট', icon: Smartphone },
  { value: 'card', label: 'ডেবিট/ক্রেডিট কার্ড', icon: CreditCard },
  { value: 'cod', label: 'ক্যাশ অন ডেলিভারি', icon: Banknote },
]

export default function CheckoutPage() {
  const cart = useShop((s) => s.cart)
  const hydrated = useShop((s) => s.hydrated)
  const clearCart = useShop((s) => s.clearCart)

  const { lines, subtotal } = resolveCart(cart)
  const [zone, setZone] = useState<Zone>('dhaka')
  const [pay, setPay] = useState<PayMethod>('cod')
  const [placed, setPlaced] = useState<string | null>(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const deliveryFee = useMemo(() => {
    if (subtotal >= DELIVERY.freeOver) return 0
    return zone === 'dhaka' ? DELIVERY.insideDhaka : DELIVERY.outsideDhaka
  }, [subtotal, zone])

  const total = subtotal + deliveryFee

  if (!hydrated) return null

  if (placed) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 px-4 py-16 text-center">
        <span className="flex size-16 items-center justify-center rounded-full bg-chart-5/10 text-chart-5">
          <CheckCircle2 className="size-8" aria-hidden="true" />
        </span>
        <h1 className="text-xl font-bold">অর্ডার সফল হয়েছে!</h1>
        <p className="text-sm text-muted-foreground">
          আপনার অর্ডার আইডি: <span className="font-semibold text-foreground">{placed}</span>. দ্রুতই আমাদের প্রতিনিধি
          ফোনে যোগাযোগ করে অর্ডার নিশ্চিত করবেন।
        </p>
        <div className="flex gap-2">
          <Button nativeButton={false} render={<Link href={`/track-order?id=${placed}`} />}>
            অর্ডার ট্র্যাক করুন
          </Button>
          <Button variant="outline" nativeButton={false} render={<Link href="/products" />}>
            আরও কেনাকাটা করুন
          </Button>
        </div>
      </div>
    )
  }

  if (lines.length === 0) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-3 px-4 py-16 text-center">
        <h1 className="text-lg font-bold">কার্ট খালি</h1>
        <p className="text-sm text-muted-foreground">চেকআউট করতে আগে কার্টে পণ্য যোগ করুন।</p>
        <Button nativeButton={false} render={<Link href="/products" />}>
          কেনাকাটা শুরু করুন
        </Button>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <h1 className="mb-6 text-xl font-bold">চেকআউট</h1>

      <form
        className="grid gap-6 lg:grid-cols-3"
        onSubmit={async (e) => {
          e.preventDefault()
          const fd = new FormData(e.currentTarget)
          setBusy(true)
          setError('')
          const res = await placeOrderAction({
            items: lines.map((l) => ({ productId: l.productId, qty: l.qty })),
            fullName: String(fd.get('name') ?? ''),
            phone: String(fd.get('phone') ?? ''),
            address: String(fd.get('address') ?? ''),
            zone,
            payment: pay,
          })
          setBusy(false)
          if (res.error || !res.orderNo) {
            setError(res.error ?? 'অর্ডার সম্পন্ন করা যায়নি')
            return
          }
          clearCart()
          setPlaced(res.orderNo)
        }}
      >
        <div className="flex flex-col gap-4 lg:col-span-2">
          <div className="rounded-2xl border bg-card p-4">
            <h2 className="mb-3 font-semibold">ডেলিভারি ঠিকানা</h2>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="name">পুরো নাম</Label>
                <Input id="name" name="name" required placeholder="আপনার নাম লিখুন" />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="phone">মোবাইল নম্বর</Label>
                <Input id="phone" name="phone" type="tel" required placeholder="01XXXXXXXXX" pattern="01[0-9]{9}" />
              </div>
            </div>
            <div className="mt-3 flex flex-col gap-1.5">
              <Label htmlFor="address">সম্পূর্ণ ঠিকানা</Label>
              <Textarea id="address" name="address" required placeholder="বাসা/ফ্ল্যাট, রোড, এলাকা, থানা, জেলা" rows={3} />
            </div>
            <div className="mt-3 flex flex-col gap-2">
              <Label>ডেলিভারি এলাকা</Label>
              <RadioGroup value={zone} onValueChange={(v) => setZone(v as Zone)} className="grid-cols-2">
                <label className="flex cursor-pointer items-center gap-2 rounded-xl border p-3 text-sm has-data-checked:border-primary has-data-checked:bg-primary/5">
                  <RadioGroupItem value="dhaka" /> ঢাকার ভেতরে ({formatTaka(DELIVERY.insideDhaka)})
                </label>
                <label className="flex cursor-pointer items-center gap-2 rounded-xl border p-3 text-sm has-data-checked:border-primary has-data-checked:bg-primary/5">
                  <RadioGroupItem value="outside" /> ঢাকার বাইরে ({formatTaka(DELIVERY.outsideDhaka)})
                </label>
              </RadioGroup>
            </div>
          </div>

          <div className="rounded-2xl border bg-card p-4">
            <h2 className="mb-3 font-semibold">পেমেন্ট পদ্ধতি</h2>
            <RadioGroup value={pay} onValueChange={(v) => setPay(v as PayMethod)} className="grid-cols-1 sm:grid-cols-2">
              {payOptions.map(({ value, label, icon: Icon }) => (
                <label
                  key={value}
                  className="flex cursor-pointer items-center gap-2 rounded-xl border p-3 text-sm has-data-checked:border-primary has-data-checked:bg-primary/5"
                >
                  <RadioGroupItem value={value} />
                  <Icon className="size-4 text-muted-foreground" aria-hidden="true" /> {label}
                </label>
              ))}
            </RadioGroup>
          </div>

        </div>

        <div className="flex flex-col gap-4">
          <div className="rounded-2xl border bg-card p-4">
            <h2 className="mb-3 font-semibold">অর্ডার সারাংশ</h2>
            <ul className="mb-3 flex flex-col gap-2 text-sm">
              {lines.map((l) => (
                <li key={`${l.productId}-${l.packId}`} className="flex items-center justify-between gap-2">
                  <span className="min-w-0 flex-1 truncate">
                    {l.product.name} × {l.qty.toLocaleString('bn-BD')}
                  </span>
                  <span className="shrink-0 font-medium">{formatTaka(l.total)}</span>
                </li>
              ))}
            </ul>
            <div className="flex justify-between border-t pt-2 text-sm">
              <span className="text-muted-foreground">সাবটোটাল</span>
              <span>{formatTaka(subtotal)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">ডেলিভারি চার্জ</span>
              <span>{deliveryFee === 0 ? 'ফ্রি' : formatTaka(deliveryFee)}</span>
            </div>
            <div className="mt-2 flex justify-between border-t pt-2 text-base font-bold">
              <span>সর্বমোট</span>
              <span className="text-primary">{formatTaka(total)}</span>
            </div>
            {error && <p className="mt-2 text-xs font-medium text-destructive">{error}</p>}
            <Button type="submit" size="lg" className="mt-4 w-full rounded-full" disabled={busy}>
              অর্ডার নিশ্চিত করুন
            </Button>
          </div>
        </div>
      </form>
    </div>
  )
}
