import type { MetadataRoute } from 'next'

const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://newmedicinehall.vercel.app'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: '*', allow: '/', disallow: ['/admin', '/seller', '/account', '/cart', '/checkout', '/wishlist', '/track-order', '/login', '/register'] }],
    sitemap: `${base}/sitemap.xml`,
  }
}
