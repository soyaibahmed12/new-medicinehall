import type { MetadataRoute } from 'next'
import { categories } from '@/lib/catalog'
import { createClient } from '@/lib/supabase/server'

const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://newmedicinehall.vercel.app'

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const supabase = await createClient()
  const { data } = await supabase.from('products').select('slug, updated_at').eq('status', 'active')
  return [
    { url: base, changeFrequency: 'daily', priority: 1 },
    { url: `${base}/products`, changeFrequency: 'daily', priority: 0.9 },
    ...categories.map((c) => ({ url: `${base}/products?category=${c.slug}`, changeFrequency: 'weekly' as const, priority: 0.7 })),
    ...(data ?? []).map((p) => ({ url: `${base}/product/${p.slug}`, lastModified: p.updated_at, changeFrequency: 'weekly' as const, priority: 0.8 })),
  ]
}
