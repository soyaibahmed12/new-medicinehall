import type { Metadata } from 'next'
import { LayoutDashboard, PlusCircle, Pill } from 'lucide-react'
import { PanelShell } from '@/components/panel/panel-shell'
import { requireRole } from '@/lib/auth'

export const metadata: Metadata = { title: 'সেলার প্যানেল', robots: { index: false, follow: false } }

export default async function SellerLayout({ children }: { children: React.ReactNode }) {
  await requireRole(['seller', 'admin'])
  return (
    <PanelShell
      title="সেলার প্যানেল"
      links={[
        { href: '/seller', label: 'ড্যাশবোর্ড', icon: LayoutDashboard },
        { href: '/seller/products', label: 'আমার পণ্য', icon: Pill },
        { href: '/seller/products/new', label: 'নতুন পণ্য', icon: PlusCircle },
      ]}
    >
      {children}
    </PanelShell>
  )
}
