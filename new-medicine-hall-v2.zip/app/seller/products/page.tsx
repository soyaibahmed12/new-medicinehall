import { ProductTable } from '@/components/panel/product-table'
import { requireRole } from '@/lib/auth'
import { createClient } from '@/lib/supabase/server'

export default async function SellerProducts() {
  const user = await requireRole(['seller', 'admin'])
  const supabase = await createClient()
  const { data } = await supabase.from('products').select('id, name, strength, slug, image_url, price, stock, status, medicine_type').eq('seller_id', user.id).order('created_at', { ascending: false })
  return <ProductTable rows={data ?? []} />
}
