import { notFound } from 'next/navigation'
import { ProductForm } from '@/components/panel/product-form'
import { requireRole } from '@/lib/auth'
import { createClient } from '@/lib/supabase/server'

export default async function EditProduct({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireRole(['seller', 'admin'])
  const { id } = await params
  const supabase = await createClient()
  const { data: p } = await supabase.from('products').select('*').eq('id', id).maybeSingle()
  if (!p || (user.role !== 'admin' && p.seller_id !== user.id)) notFound()
  return <ProductForm isAdmin={user.role === 'admin'} values={{ ...p, price: Number(p.price), mrp: Number(p.mrp) }} />
}
