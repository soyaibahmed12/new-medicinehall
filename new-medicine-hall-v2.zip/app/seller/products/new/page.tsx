import { ProductForm } from '@/components/panel/product-form'
import { requireRole } from '@/lib/auth'

export default async function NewProduct() {
  const user = await requireRole(['seller', 'admin'])
  return <ProductForm isAdmin={user.role === 'admin'} />
}
