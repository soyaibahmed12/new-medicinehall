import Link from 'next/link'
import { EyeOff, PlusCircle, Pill } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { StatCard } from '@/components/panel/panel-shell'
import { requireRole } from '@/lib/auth'
import { createClient } from '@/lib/supabase/server'
import { bn } from '@/lib/catalog'

export default async function SellerDashboard() {
  const user = await requireRole(['seller', 'admin'])
  const supabase = await createClient()
  const { data } = await supabase.from('products').select('status, stock').eq('seller_id', user.id)
  const list = data ?? []
  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <StatCard label="আমার পণ্য" value={bn(list.length)} icon={Pill} />
        <StatCard label="সাইটে দৃশ্যমান" value={bn(list.filter((p) => p.status === 'active').length)} icon={Pill} tint="bg-chart-5/10 text-chart-5" />
        <StatCard label="লুকানো" value={bn(list.filter((p) => p.status === 'hidden').length)} icon={EyeOff} tint="bg-muted text-muted-foreground" />
      </div>
      <Button size="lg" className="w-fit rounded-full" nativeButton={false} render={<Link href="/seller/products/new" />}>
        <PlusCircle data-icon="inline-start" /> নতুন পণ্য যোগ করুন
      </Button>
    </div>
  )
}
