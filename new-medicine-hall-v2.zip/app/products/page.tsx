import Link from 'next/link'
import type { Metadata } from 'next'
import { PackageSearch } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty'
import { Button } from '@/components/ui/button'
import { CategoryIcon } from '@/components/category-icon'
import { ProductCard } from '@/components/product/product-card'
import { categories, categoryName, medicineTypeLabel, medicineTypes } from '@/lib/catalog'
import { getProducts } from '@/lib/queries'
import { cn } from '@/lib/utils'

export const metadata: Metadata = { title: 'সকল ঔষধ ও প্রোডাক্ট' }

type SearchParams = { category?: string; q?: string; deal?: string; sort?: string; type?: string }

export default async function ProductsPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const sp = await searchParams
  const list = await getProducts({ category: sp.category, q: sp.q, deal: sp.deal, sort: sp.sort, type: sp.type })

  const sortLinks: { key: string; label: string }[] = [
    { key: '', label: 'জনপ্রিয়তা' },
    { key: 'bestseller', label: 'সবচেয়ে বেশি বিক্রিত' },
    { key: 'price-asc', label: 'কম দাম আগে' },
    { key: 'price-desc', label: 'বেশি দাম আগে' },
  ]

  const withSort = (key: string) => {
    const params = new URLSearchParams()
    if (sp.category) params.set('category', sp.category)
    if (sp.q) params.set('q', sp.q)
    if (sp.deal) params.set('deal', sp.deal)
    if (sp.type) params.set('type', sp.type)
    if (key) params.set('sort', key)
    const qs = params.toString()
    return qs ? `/products?${qs}` : '/products'
  }

  return (
    <div className="mx-auto flex max-w-7xl gap-6 px-4 py-6">
      <aside className="hidden w-56 shrink-0 lg:block">
        <h2 className="mb-3 text-sm font-semibold text-muted-foreground">ক্যাটাগরি</h2>
        <nav className="flex flex-col gap-1">
          <Link
            href="/products"
            className={cn(
              'flex items-center gap-2 rounded-lg px-2.5 py-2 text-sm font-medium hover:bg-muted',
              !sp.category && 'bg-primary/10 text-primary',
            )}
          >
            সব ক্যাটাগরি
          </Link>
          {categories.map((c) => (
            <Link
              key={c.slug}
              href={`/products?category=${c.slug}`}
              className={cn(
                'flex items-center gap-2 rounded-lg px-2.5 py-2 text-sm font-medium hover:bg-muted',
                sp.category === c.slug && 'bg-primary/10 text-primary',
              )}
            >
              <CategoryIcon name={c.icon} className="size-4" /> {c.name}
            </Link>
          ))}
        </nav>
      </aside>

      <div className="min-w-0 flex-1">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-bold">
              {sp.q ? `"${sp.q}" এর ফলাফল` : sp.type ? medicineTypeLabel(sp.type) : sp.category ? categoryName(sp.category) : 'সকল ঔষধ ও প্রোডাক্ট'}
            </h1>
            <p className="text-sm text-muted-foreground">{list.length.toLocaleString('bn-BD')} টি পণ্য পাওয়া গেছে</p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {sortLinks.map((s) => (
              <Link key={s.key} href={withSort(s.key)}>
                <Badge
                  variant={(sp.sort ?? '') === s.key ? 'default' : 'outline'}
                  className="cursor-pointer px-3 py-1.5"
                >
                  {s.label}
                </Badge>
              </Link>
            ))}
          </div>
        </div>

        <div className="no-scrollbar mb-3 flex gap-2 overflow-x-auto">
          <Link href="/products">
            <Badge variant={!sp.type ? 'default' : 'outline'} className="shrink-0 px-3 py-1.5">সব ধরন</Badge>
          </Link>
          {medicineTypes.map((m) => (
            <Link key={m.value} href={`/products?type=${m.value}`}>
              <Badge variant={sp.type === m.value ? 'default' : 'outline'} className="shrink-0 px-3 py-1.5">{m.label}</Badge>
            </Link>
          ))}
        </div>

        {/* Mobile category chips */}
        <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto lg:hidden">
          <Link href="/products">
            <Badge variant={!sp.category ? 'default' : 'outline'} className="shrink-0 px-3 py-1.5">
              সব
            </Badge>
          </Link>
          {categories.map((c) => (
            <Link key={c.slug} href={`/products?category=${c.slug}`}>
              <Badge variant={sp.category === c.slug ? 'default' : 'outline'} className="shrink-0 px-3 py-1.5">
                {c.name}
              </Badge>
            </Link>
          ))}
        </div>

        {list.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <PackageSearch />
              </EmptyMedia>
              <EmptyTitle>কোনো পণ্য পাওয়া যায়নি</EmptyTitle>
              <EmptyDescription>অন্য কীওয়ার্ড দিয়ে খুঁজুন।</EmptyDescription>
            </EmptyHeader>
            <EmptyContent>
              <Button nativeButton={false} render={<Link href="/products" />}>
                সব পণ্য দেখুন
              </Button>
            </EmptyContent>
          </Empty>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
            {list.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
