import type { Metadata } from 'next'
import { AuthForm } from '@/components/auth/auth-form'
import { Logo } from '@/components/layout/logo'

export const metadata: Metadata = { title: 'রেজিস্ট্রেশন' }

export default async function Page({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams
  const safe = next && next.startsWith('/') && !next.startsWith('//') ? next : '/'
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-4 py-10">
      <div className="rounded-3xl border bg-card p-6 shadow-sm sm:p-8">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <Logo />
          <h1 className="text-xl font-bold">রেজিস্ট্রেশন</h1>
          <p className="text-sm text-muted-foreground">কয়েক সেকেন্ডেই অ্যাকাউন্ট খুলুন এবং কেনাকাটা শুরু করুন।</p>
        </div>
        <AuthForm mode="register" next={safe} />
      </div>
    </div>
  )
}
