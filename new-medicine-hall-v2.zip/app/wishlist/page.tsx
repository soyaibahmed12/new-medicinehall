import type { Metadata } from 'next'
import { WishlistView } from '@/components/product/wishlist-view'

export const metadata: Metadata = { title: 'উইশলিস্ট', robots: { index: false } }

export default function WishlistPage() {
  return <WishlistView />
}
