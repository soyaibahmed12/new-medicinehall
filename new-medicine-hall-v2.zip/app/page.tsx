import Image from 'next/image'
import Link from 'next/link'
import { PackageCheck, ShieldCheck, Truck, Undo2, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel'
import { CategoryIcon } from '@/components/category-icon'
import { ProductCard } from '@/components/product/product-card'
import { categories, medicineTypes } from '@/lib/catalog'
import { getProducts } from '@/lib/queries'

const banners = [
  { src: '/banners/hero-1.png', alt: 'সকল ঔষধে বিশেষ ছাড়' },
  { src: '/banners/hero-2.png', alt: 'ফ্রি হোম ডেলিভারি অফার' },
  { src: '/banners/hero-3.png', alt: 'ডায়াবেটিস কেয়ার প্যাকেজ' },
]

const trust = [
  { icon: ShieldCheck, title: '১০০% আসল ঔষধ', desc: 'DGDA অনুমোদিত ও সরাসরি কোম্পানি থেকে সংগৃহীত' },
  { icon: Truck, title: '৬৪ জেলায় ডেলিভারি', desc: 'ঢাকায় ২৪ ঘণ্টা, দেশজুড়ে ২-৩ দিনে' },
  { icon: PackageCheck, title: 'সব ধরনের ঔষধ', desc: 'এলোপ্যাথিক, আয়ুর্বেদিক, হোমিওপ্যাথিক, ইউনানি ও হারবাল' },
  { icon: Undo2, title: 'সহজ রিটার্ন', desc: 'ভুল বা ক্ষতিগ্রস্ত পণ্যে ঝামেলাহীন রিটার্ন' },
]

const faqs = [
  {
    q: 'অর্ডার করতে কি প্রেসক্রিপশন লাগবে?',
    a: 'প্রেসক্রিপশন বাধ্যতামূলক নয়। তবে চিকিৎসকের পরামর্শ অনুযায়ী ঔষধ সেবন করাই নিরাপদ।',
  },
  {
    q: 'ডেলিভারি চার্জ কত?',
    a: 'ঢাকার ভেতরে ৳৬০, ঢাকার বাইরে ৳১২০। ৳১,০০০ বা তার বেশি অর্ডারে ডেলিভারি সম্পূর্ণ ফ্রি।',
  },
  {
    q: 'পেমেন্ট পদ্ধতি কী কী?',
    a: 'বিকাশ, নগদ, রকেট, ডেবিট/ক্রেডিট কার্ড এবং ক্যাশ অন ডেলিভারি (COD) — সবগুলোই সাপোর্ট করা হয়।',
  },
  {
    q: 'ভুল ঔষধ পেলে কী করব?',
    a: 'ডেলিভারির ৭ দিনের মধ্যে হটলাইনে জানালে আমরা বিনামূল্যে পিকআপ করে সঠিক পণ্য পৌঁছে দেব অথবা টাকা ফেরত দেব।',
  },
]

export default async function HomePage() {
  const [flash, bestsellers, latest] = await Promise.all([
    getProducts({ deal: 'flash', limit: 6 }),
    getProducts({ sort: 'bestseller', limit: 6 }),
    getProducts({ sort: 'new', limit: 6 }),
  ])
  const trending = latest

  return (
    <div className="mx-auto flex max-w-7xl flex-col gap-10 px-4 py-6">
      {/* Hero */}
      <section aria-label="ফিচারড অফার">
        <Carousel opts={{ loop: true }} className="group">
          <CarouselContent>
            {banners.map((b) => (
              <CarouselItem key={b.src}>
                <div className="relative aspect-[16/7] w-full overflow-hidden rounded-2xl bg-muted sm:aspect-[21/7]">
                  <Image src={b.src} alt={b.alt} fill priority className="object-cover" sizes="100vw" />
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="left-3 opacity-0 group-hover:opacity-100" />
          <CarouselNext className="right-3 opacity-0 group-hover:opacity-100" />
        </Carousel>
      </section>

      {/* Trust badges */}
      <section aria-label="কেন আমাদের বেছে নেবেন" className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {trust.map(({ icon: Icon, title, desc }) => (
          <div key={title} className="flex flex-col items-start gap-2 rounded-2xl border bg-card p-4">
            <span className="flex size-9 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Icon className="size-4.5" aria-hidden="true" />
            </span>
            <p className="text-sm font-semibold">{title}</p>
            <p className="text-xs text-muted-foreground">{desc}</p>
          </div>
        ))}
      </section>

      {/* Categories */}
      <section aria-labelledby="cat-heading" className="flex flex-col gap-4">
        <h2 id="cat-heading" className="text-lg font-bold">
          ক্যাটাগরি অনুযায়ী কিনুন
        </h2>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
          {categories.map((c) => (
            <Link
              key={c.slug}
              href={`/products?category=${c.slug}`}
              className="flex flex-col items-center gap-2 rounded-2xl border bg-card p-4 text-center transition-colors hover:border-primary/40 hover:bg-muted/50"
            >
              <span className={`flex size-11 items-center justify-center rounded-xl ${c.tint}`}>
                <CategoryIcon name={c.icon} className="size-5" />
              </span>
              <span className="text-xs leading-tight font-medium">{c.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Medicine types */}
      <section aria-labelledby="type-heading" className="flex flex-col gap-4">
        <h2 id="type-heading" className="text-lg font-bold">
          চিকিৎসা পদ্ধতি অনুযায়ী
        </h2>
        <div className="flex flex-wrap gap-2">
          {medicineTypes.map((m) => (
            <Link key={m.value} href={`/products?type=${m.value}`}>
              <Badge variant="outline" className="h-auto px-4 py-2 text-sm hover:border-primary hover:text-primary">
                {m.label}
              </Badge>
            </Link>
          ))}
        </div>
      </section>

      {/* Flash sale */}
      {flash.length > 0 && <section aria-labelledby="flash-heading" className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h2 id="flash-heading" className="flex items-center gap-2 text-lg font-bold">
            <Badge className="gap-1 bg-deal text-deal-foreground">
              <Zap aria-hidden="true" /> ফ্ল্যাশ সেল
            </Badge>
          </h2>
          <Link href="/products?deal=flash" className="text-sm font-medium text-primary hover:underline">
            সব দেখুন
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {flash.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>}

      {/* Bestsellers */}
      <section aria-labelledby="best-heading" className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h2 id="best-heading" className="text-lg font-bold">
            জনপ্রিয় ঔষধ
          </h2>
          <Link href="/products?sort=bestseller" className="text-sm font-medium text-primary hover:underline">
            সব দেখুন
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {bestsellers.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Trending */}
      <section aria-labelledby="trend-heading" className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h2 id="trend-heading" className="text-lg font-bold">
            নতুন ও ট্রেন্ডিং
          </h2>
          <Link href="/products" className="text-sm font-medium text-primary hover:underline">
            সব দেখুন
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {trending.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" aria-labelledby="faq-heading" className="flex flex-col gap-2 scroll-mt-20">
        <h2 id="faq-heading" className="mb-2 text-lg font-bold">
          সাধারণ জিজ্ঞাসা
        </h2>
        <Accordion className="rounded-2xl border bg-card px-4">
          {faqs.map((f, i) => (
            <AccordionItem key={i} value={String(i)}>
              <AccordionTrigger>{f.q}</AccordionTrigger>
              <AccordionContent>{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>
    </div>
  )
}
