import Link from 'next/link'
import { WifiOff } from 'lucide-react'
import { Button } from '@/components/ui/button'

export const metadata = { title: 'অফলাইন' }

export default function OfflinePage() {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center gap-4 px-4 text-center">
      <span className="flex size-16 items-center justify-center rounded-full bg-muted">
        <WifiOff className="size-7 text-muted-foreground" aria-hidden="true" />
      </span>
      <h1 className="text-xl font-bold">ইন্টারনেট সংযোগ নেই</h1>
      <p className="text-sm text-muted-foreground">
        আপনি বর্তমানে অফলাইনে আছেন। ইন্টারনেট সংযোগ ফিরে এলে পুনরায় চেষ্টা করুন। আগে দেখা কিছু পেজ ও পণ্যের ছবি
        অফলাইনেও দেখা যেতে পারে।
      </p>
      <Button nativeButton={false} render={<Link href="/" />}>
        হোমপেজে ফিরে যান
      </Button>
    </div>
  )
}
