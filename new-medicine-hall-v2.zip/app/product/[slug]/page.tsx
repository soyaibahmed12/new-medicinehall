import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import { ChevronRight, ShieldCheck, Star, Truck } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { AddToCartPanel } from '@/components/product/add-to-cart-panel'
import { ProductCard } from '@/components/product/product-card'
import { bn, categoryName, discountPercent, medicineTypeLabel } from '@/lib/catalog'
import { getProductBySlug, getProducts } from '@/lib/queries'

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const product = await getProductBySlug(slug)
  if (!product) return {}
  return {
    title: `${product.name} ${product.strength}`,
    description: product.description,
  }
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const product = await getProductBySlug(slug)
  if (!product) notFound()

  const pack = product.packs[0]
  const off = discountPercent(pack)
  const related = (await getProducts({ category: product.category, limit: 7 })).filter((p) => p.id !== product.id).slice(0, 6)

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Product',
            name: `${product.name} ${product.strength}`.trim(),
            description: product.description,
            image: product.image,
            brand: product.company ? { '@type': 'Brand', name: product.company } : undefined,
            offers: {
              '@type': 'Offer',
              priceCurrency: 'BDT',
              price: pack.price,
              availability: product.stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
            },
          }).replace(/</g, '\\u003c'),
        }}
      />
      <nav aria-label="ব্রেডক্রাম্ব" className="mb-4 flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
        <Link href="/" className="hover:text-foreground">
          হোম
        </Link>
        <ChevronRight className="size-3" aria-hidden="true" />
        <Link href={`/products?category=${product.category}`} className="hover:text-foreground">
          {categoryName(product.category)}
        </Link>
        <ChevronRight className="size-3" aria-hidden="true" />
        <span className="truncate text-foreground">{product.name}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-2">
        <div className="relative aspect-square overflow-hidden rounded-2xl border bg-muted/50">
          <Image
            src={product.image}
            alt={`${product.name} ${product.strength}`}
            fill
            sizes="(min-width: 1024px) 50vw, 100vw"
            className="object-contain p-8"
            priority
          />
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {off > 0 && <Badge className="bg-deal text-deal-foreground">{bn(off)}% ছাড়</Badge>}
            <Badge variant="secondary">{medicineTypeLabel(product.medicineType)}</Badge>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div>
            <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">{product.company}</p>
            <h1 className="text-2xl font-bold">
              {product.name} <span className="font-normal text-muted-foreground">{product.strength}</span>
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {product.form} · জেনেরিক: {product.generic}
            </p>
          </div>

          <div className="flex items-center gap-3 text-sm">
            <span className="flex items-center gap-1 font-semibold">
              <Star className="size-4 fill-chart-4 text-chart-4" aria-hidden="true" /> {bn(product.rating)}
            </span>
            <span className="text-muted-foreground">({bn(product.reviews)} রিভিউ)</span>
            <span className="text-muted-foreground">· {bn(product.sold)}+ বিক্রি হয়েছে</span>
          </div>

          <p className="text-sm leading-relaxed text-muted-foreground">{product.description}</p>

          <div className="flex items-center gap-2 rounded-xl bg-muted/60 p-3 text-xs">
            <ShieldCheck className="size-4 shrink-0 text-primary" aria-hidden="true" />
            ১০০% আসল পণ্যের নিশ্চয়তা
            <span className="mx-1 text-border">|</span>
            <Truck className="size-4 shrink-0 text-primary" aria-hidden="true" />
            {product.stock > 0 ? 'আজই অর্ডার করলে দ্রুত ডেলিভারি' : 'বর্তমানে স্টকে নেই'}
          </div>

          <AddToCartPanel product={product} />

        </div>
      </div>

      <div className="mt-10 max-w-4xl">
        <Tabs defaultValue="uses">
          <TabsList>
            <TabsTrigger value="uses">ব্যবহার</TabsTrigger>
            <TabsTrigger value="dosage">সেবনবিধি</TabsTrigger>
            <TabsTrigger value="side-effects">পার্শ্বপ্রতিক্রিয়া</TabsTrigger>
            <TabsTrigger value="warnings">সতর্কতা</TabsTrigger>
          </TabsList>
          <TabsContent value="uses" className="pt-3">
            <ul className="list-inside list-disc space-y-1">
              {product.uses.map((u) => (
                <li key={u}>{u}</li>
              ))}
            </ul>
          </TabsContent>
          <TabsContent value="dosage" className="pt-3">
            {product.dosage}
          </TabsContent>
          <TabsContent value="side-effects" className="pt-3">
            <ul className="list-inside list-disc space-y-1">
              {product.sideEffects.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
          </TabsContent>
          <TabsContent value="warnings" className="pt-3">
            {product.warnings}
          </TabsContent>
        </Tabs>
      </div>

      {related.length > 0 && (
        <section className="mt-12">
          <h2 className="mb-4 text-lg font-bold">একই ক্যাটাগরির অন্যান্য পণ্য</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
