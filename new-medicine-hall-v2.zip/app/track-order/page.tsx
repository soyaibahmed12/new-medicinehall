import type { Metadata } from 'next'
import Link from 'next/link'
import { CheckCircle2, Circle, PackageOpen } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { requireUser } from '@/lib/auth'
import { createClient } from '@/lib/supabase/server'
import { formatTaka } from '@/lib/catalog'
import { cn } from '@/lib/utils'

export const metadata: Metadata = { title: 'আমার অর্ডার', robots: { index: false } }

const steps = [
  { key: 'placed', label: 'অর্ডার গৃহীত' },
  { key: 'confirmed', label: 'নিশ্চিত' },
  { key: 'shipped', label: 'পথে আছে' },
  { key: 'delivered', label: 'ডেলিভারি সম্পন্ন' },
]

export default async function OrdersPage() {
  const user = await requireUser('/track-order')
  const supabase = await createClient()
  const { data: orders } = await supabase.from('orders').select('*').eq('user_id', user.id).order('created_at', { ascending: false })

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="mb-6 text-xl font-bold">আমার অর্ডার</h1>
      {!orders?.length ? (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed p-10 text-center">
          <PackageOpen className="size-8 text-muted-foreground" aria-hidden="true" />
          <p className="text-sm text-muted-foreground">আপনি এখনো কোনো অর্ডার করেননি।</p>
          <Button nativeButton={false} render={<Link href="/products" />}>কেনাকাটা শুরু করুন</Button>
        </div>
      ) : (
        <ul className="flex flex-col gap-4">
          {orders.map((o) => {
            const cancelled = o.status === 'cancelled'
            const active = steps.findIndex((s) => s.key === o.status)
            return (
              <li key={o.id} className="rounded-2xl border bg-card p-4">
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <p className="font-semibold">{o.order_no}</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(o.created_at).toLocaleDateString('bn-BD')} · <span className="font-semibold text-primary">{formatTaka(Number(o.total))}</span>
                  </p>
                </div>
                <ul className="mb-3 text-sm text-muted-foreground">
                  {(o.items as { name: string; qty: number }[]).map((it, i) => (
                    <li key={i}>{it.name} × {it.qty.toLocaleString('bn-BD')}</li>
                  ))}
                </ul>
                {cancelled ? (
                  <p className="text-sm font-medium text-destructive">অর্ডারটি বাতিল করা হয়েছে</p>
                ) : (
                  <ol className="grid grid-cols-4 gap-1 text-center text-[11px]">
                    {steps.map((s, i) => (
                      <li key={s.key} className={cn('flex flex-col items-center gap-1', i <= active ? 'text-primary' : 'text-muted-foreground')}>
                        {i <= active ? <CheckCircle2 className="size-5" aria-hidden="true" /> : <Circle className="size-5" aria-hidden="true" />}
                        {s.label}
                      </li>
                    ))}
                  </ol>
                )}
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
