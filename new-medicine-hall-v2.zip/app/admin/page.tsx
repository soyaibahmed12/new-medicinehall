import Link from 'next/link'
import { Banknote, Package, Pill, Store, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { StatCard } from '@/components/panel/panel-shell'
import { createClient } from '@/lib/supabase/server'
import { bn, formatTaka } from '@/lib/catalog'

export default async function AdminDashboard() {
  const supabase = await createClient()
  const [users, sellers, products, orders, revenue] = await Promise.all([
    supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', 'user'),
    supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', 'seller'),
    supabase.from('products').select('*', { count: 'exact', head: true }),
    supabase.from('orders').select('*', { count: 'exact', head: true }),
    supabase.from('orders').select('total').neq('status', 'cancelled'),
  ])
  const total = (revenue.data ?? []).reduce((s, o) => s + Number(o.total), 0)
  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard label="গ্রাহক" value={bn(users.count ?? 0)} icon={Users} />
        <StatCard label="সেলার" value={bn(sellers.count ?? 0)} icon={Store} tint="bg-chart-3/10 text-chart-3" />
        <StatCard label="মোট পণ্য" value={bn(products.count ?? 0)} icon={Pill} tint="bg-chart-5/10 text-chart-5" />
        <StatCard label="মোট অর্ডার" value={bn(orders.count ?? 0)} icon={Package} tint="bg-deal/10 text-deal" />
        <StatCard label="মোট বিক্রি" value={formatTaka(total)} icon={Banknote} tint="bg-chart-4/15 text-chart-2" />
      </div>
      <div className="flex flex-wrap gap-2">
        <Button nativeButton={false} render={<Link href="/admin/users" />}>সেলার নিয়োগ করুন</Button>
        <Button variant="outline" nativeButton={false} render={<Link href="/seller/products/new" />}>নতুন পণ্য যোগ করুন</Button>
      </div>
    </div>
  )
}
