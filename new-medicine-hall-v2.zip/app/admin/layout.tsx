import type { Metadata } from 'next'
import { LayoutDashboard, Package, Pill, Users } from 'lucide-react'
import { PanelShell } from '@/components/panel/panel-shell'
import { requireRole } from '@/lib/auth'

export const metadata: Metadata = { title: 'অ্যাডমিন প্যানেল', robots: { index: false, follow: false } }

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireRole(['admin'])
  return (
    <PanelShell
      title="অ্যাডমিন প্যানেল"
      links={[
        { href: '/admin', label: 'ড্যাশবোর্ড', icon: LayoutDashboard },
        { href: '/admin/users', label: 'ইউজার ও সেলার', icon: Users },
        { href: '/admin/products', label: 'সব পণ্য', icon: Pill },
        { href: '/admin/orders', label: 'অর্ডার', icon: Package },
      ]}
    >
      {children}
    </PanelShell>
  )
}
