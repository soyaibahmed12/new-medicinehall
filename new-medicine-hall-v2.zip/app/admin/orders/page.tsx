import { createClient } from '@/lib/supabase/server'
import { setOrderStatusAction } from '@/lib/actions/admin'
import { formatTaka } from '@/lib/catalog'
import { Button } from '@/components/ui/button'

const statuses = [
  ['placed', 'গৃহীত'],
  ['confirmed', 'নিশ্চিত'],
  ['shipped', 'পথে'],
  ['delivered', 'ডেলিভারড'],
  ['cancelled', 'বাতিল'],
]

export default async function AdminOrders() {
  const supabase = await createClient()
  const { data: orders } = await supabase.from('orders').select('*').order('created_at', { ascending: false }).limit(100)
  return (
    <div className="flex flex-col gap-3">
      {!orders?.length && <p className="rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">এখনো কোনো অর্ডার নেই।</p>}
      {orders?.map((o) => (
        <div key={o.id} className="rounded-2xl border bg-card p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="font-semibold">{o.order_no}</p>
            <p className="text-sm font-semibold text-primary">{formatTaka(Number(o.total))}</p>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            {o.full_name} · {o.phone} · {o.address}
          </p>
          <ul className="mt-2 text-sm">
            {(o.items as { name: string; qty: number }[]).map((it, i) => (
              <li key={i}>{it.name} × {it.qty}</li>
            ))}
          </ul>
          <form action={setOrderStatusAction} className="mt-3 flex items-center gap-2">
            <input type="hidden" name="id" value={o.id} />
            <select name="status" defaultValue={o.status} className="h-9 rounded-lg border bg-background px-2 text-sm">
              {statuses.map(([v, l]) => (
                <option key={v} value={v}>{l}</option>
              ))}
            </select>
            <Button type="submit" size="sm">আপডেট</Button>
          </form>
        </div>
      ))}
    </div>
  )
}
