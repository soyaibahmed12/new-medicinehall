import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { createClient } from '@/lib/supabase/server'
import { setRoleAction } from '@/lib/actions/admin'

const roleLabel = { admin: 'অ্যাডমিন', seller: 'সেলার', user: 'গ্রাহক' } as const

export default async function AdminUsers() {
  const supabase = await createClient()
  const { data: people } = await supabase.from('profiles').select('id, full_name, phone, role, created_at').order('created_at', { ascending: false })
  return (
    <div className="overflow-hidden rounded-2xl border bg-card">
      <p className="border-b bg-muted/40 p-3 text-sm text-muted-foreground">
        শুধু আপনি (অ্যাডমিন) কাউকে সেলার বানাতে পারবেন। সেলার হিসেবে নিয়োগ পাওয়ার পর সে নিজের পণ্য যোগ ও পরিচালনা করতে পারবে।
      </p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="p-3">নাম</th>
              <th className="p-3">মোবাইল</th>
              <th className="p-3">ভূমিকা</th>
              <th className="p-3 text-right">অ্যাকশন</th>
            </tr>
          </thead>
          <tbody>
            {(people ?? []).map((p) => (
              <tr key={p.id} className="border-t">
                <td className="p-3 font-medium">{p.full_name || '—'}</td>
                <td className="p-3">{p.phone || '—'}</td>
                <td className="p-3">
                  <Badge variant={p.role === 'user' ? 'outline' : 'default'}>{roleLabel[p.role as keyof typeof roleLabel]}</Badge>
                </td>
                <td className="p-3 text-right">
                  {p.role === 'admin' ? null : (
                    <form action={setRoleAction}>
                      <input type="hidden" name="id" value={p.id} />
                      <input type="hidden" name="role" value={p.role === 'seller' ? 'user' : 'seller'} />
                      <Button type="submit" size="sm" variant={p.role === 'seller' ? 'outline' : 'default'}>
                        {p.role === 'seller' ? 'সেলার সরান' : 'সেলার বানান'}
                      </Button>
                    </form>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
