import { ProductTable } from '@/components/panel/product-table'
import { createClient } from '@/lib/supabase/server'

export default async function AdminProducts() {
  const supabase = await createClient()
  const { data } = await supabase
    .from('products')
    .select('id, name, strength, slug, image_url, price, stock, status, medicine_type, profiles(full_name)')
    .order('created_at', { ascending: false })
  const rows = (data ?? []).map((r) => {
    const prof = r.profiles as unknown as { full_name: string } | { full_name: string }[] | null
    const seller = Array.isArray(prof) ? prof[0]?.full_name : prof?.full_name
    return { ...r, seller: seller || '—' }
  })
  return <ProductTable rows={rows} showSeller />
}
