import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Hind_Siliguri } from 'next/font/google'
import { Providers } from '@/components/providers'
import { SiteHeader } from '@/components/layout/site-header'
import { SiteFooter } from '@/components/layout/site-footer'
import { MobileNav } from '@/components/layout/mobile-nav'
import { CartSheet } from '@/components/cart/cart-sheet'
import { FloatingHelp } from '@/components/layout/floating-help'
import { AuthProvider } from '@/components/auth/auth-context'
import { getSessionUser } from '@/lib/auth'
import './globals.css'

const hind = Hind_Siliguri({
  subsets: ['bengali', 'latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-hind',
  display: 'swap',
})

export const metadata: Metadata = {
  title: {
    default: 'New Medicine Hall — অনলাইন ফার্মেসি | ঘরে বসে ঔষধ',
    template: '%s | New Medicine Hall',
  },
  description:
    'New Medicine Hall — বাংলাদেশের ৬৪ জেলায় ১০০% আসল ঔষধ, ডায়াবেটিস কেয়ার, মেডিকেল ডিভাইস ও হেলথ প্রোডাক্ট ঘরে পৌঁছে দেয়। প্রেসক্রিপশন আপলোড, ক্যাশ অন ডেলিভারি, বিকাশ ও নগদ পেমেন্ট।',
  applicationName: 'New Medicine Hall',
  keywords: ['online pharmacy bangladesh', 'ঔষধ', 'medicine delivery', 'New Medicine Hall', 'অনলাইন ফার্মেসি'],
  manifest: '/manifest.webmanifest',
  appleWebApp: { capable: true, title: 'New Medicine Hall', statusBarStyle: 'default' },
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', sizes: '32x32' },
      { url: '/icons/nmh-192.png', sizes: '192x192' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#0f766e' },
    { media: '(prefers-color-scheme: dark)', color: '#10232a' },
  ],
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const user = await getSessionUser()
  const headerUser = user ? { fullName: user.fullName, email: user.email, role: user.role } : null
  return (
    <html lang="bn" className={hind.variable} suppressHydrationWarning>
      <body className="font-sans antialiased">
        <Providers>
          <AuthProvider loggedIn={!!user}>
          <SiteHeader user={headerUser} />
          <main className="min-h-[60vh] pb-20 lg:pb-0">{children}</main>
          <SiteFooter />
          <MobileNav loggedIn={!!user} />
          <CartSheet />
          <FloatingHelp />
          </AuthProvider>
        </Providers>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
