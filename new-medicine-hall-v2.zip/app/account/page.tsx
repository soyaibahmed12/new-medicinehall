import Link from 'next/link'
import type { Metadata } from 'next'
import { LayoutDashboard, LogOut, Package, Store } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ProfileForm } from '@/components/account/profile-form'
import { logoutAction } from '@/lib/actions/auth'
import { requireUser } from '@/lib/auth'

export const metadata: Metadata = { title: 'আমার প্রোফাইল', robots: { index: false } }

const roleLabel = { admin: 'অ্যাডমিন', seller: 'সেলার', user: 'গ্রাহক' } as const

export default async function AccountPage() {
  const user = await requireUser('/account')
  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <div className="mb-6 flex items-center gap-4">
        <span className="flex size-14 items-center justify-center rounded-full bg-primary/10 text-xl font-bold text-primary">
          {(user.fullName || user.email).charAt(0).toUpperCase()}
        </span>
        <div>
          <h1 className="text-xl font-bold">{user.fullName || 'আমার প্রোফাইল'}</h1>
          <Badge variant={user.role === 'user' ? 'outline' : 'default'}>{roleLabel[user.role]}</Badge>
        </div>
      </div>

      <div className="mb-6 flex flex-wrap gap-2">
        <Button variant="outline" nativeButton={false} render={<Link href="/track-order" />}>
          <Package data-icon="inline-start" /> আমার অর্ডার
        </Button>
        {user.role === 'admin' && (
          <Button variant="secondary" nativeButton={false} render={<Link href="/admin" />}>
            <LayoutDashboard data-icon="inline-start" /> অ্যাডমিন প্যানেল
          </Button>
        )}
        {(user.role === 'seller' || user.role === 'admin') && (
          <Button variant="secondary" nativeButton={false} render={<Link href="/seller" />}>
            <Store data-icon="inline-start" /> সেলার প্যানেল
          </Button>
        )}
      </div>

      <div className="rounded-2xl border bg-card p-5">
        <h2 className="mb-4 font-semibold">ব্যক্তিগত তথ্য</h2>
        <ProfileForm fullName={user.fullName} phone={user.phone} email={user.email} />
      </div>

      <form action={logoutAction} className="mt-6">
        <Button type="submit" variant="outline" className="text-destructive">
          <LogOut data-icon="inline-start" /> লগআউট
        </Button>
      </form>
    </div>
  )
}
