'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ShoppingBag, Tag } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty'
import { CartLineItem } from '@/components/cart/cart-line-item'
import { FreeDeliveryMeter } from '@/components/cart/cart-sheet'
import { bn, couponDiscount, formatTaka } from '@/lib/catalog'
import { resolveCart, useShop } from '@/lib/store'

export default function CartPage() {
  const cart = useShop((s) => s.cart)
  const hydrated = useShop((s) => s.hydrated)
  const [code, setCode] = useState('')
  const [applied, setApplied] = useState<{ code: string; amount: number; reason: string } | null>(null)

  const { lines, subtotal, savings, count } = resolveCart(cart)
  const couponAmount = applied?.amount ?? 0
  const total = Math.max(0, subtotal - couponAmount)

  if (!hydrated) return null

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <h1 className="mb-6 flex items-center gap-2 text-xl font-bold">
        <ShoppingBag className="size-5 text-primary" aria-hidden="true" /> আমার কার্ট ({bn(count)} টি আইটেম)
      </h1>

      {lines.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <ShoppingBag />
            </EmptyMedia>
            <EmptyTitle>আপনার কার্ট খালি</EmptyTitle>
            <EmptyDescription>প্রয়োজনীয় ঔষধ কার্টে যোগ করুন অথবা প্রেসক্রিপশন আপলোড করুন।</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button nativeButton={false} render={<Link href="/products" />}>
              কেনাকাটা শুরু করুন
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="flex flex-col gap-4 lg:col-span-2">
            <FreeDeliveryMeter subtotal={subtotal} />
            <ul className="flex flex-col divide-y rounded-2xl border bg-card px-4">
              {lines.map((l) => (
                <CartLineItem key={`${l.productId}-${l.packId}`} line={l} />
              ))}
            </ul>
          </div>

          <div className="flex flex-col gap-4">
            <div className="rounded-2xl border bg-card p-4">
              <label htmlFor="coupon" className="mb-2 flex items-center gap-1.5 text-sm font-semibold">
                <Tag className="size-4" aria-hidden="true" /> কুপন কোড
              </label>
              <div className="flex gap-2">
                <Input
                  id="coupon"
                  placeholder="যেমন: NMH10"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                />
                <Button
                  variant="outline"
                  onClick={() => {
                    const result = couponDiscount(code, subtotal)
                    if (result.ok) setApplied({ code: code.trim().toUpperCase(), amount: result.amount, reason: result.reason })
                    else setApplied(null)
                    if (!result.ok) alert(result.reason)
                  }}
                >
                  প্রয়োগ করুন
                </Button>
              </div>
              {applied && (
                <p className="mt-2 text-xs font-medium text-chart-5">
                  &ldquo;{applied.code}&rdquo; প্রয়োগ হয়েছে — {formatTaka(applied.amount)} ছাড়
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2 rounded-2xl border bg-card p-4">
              <h2 className="mb-1 font-semibold">অর্ডার সারাংশ</h2>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">সাবটোটাল</span>
                <span>{formatTaka(subtotal)}</span>
              </div>
              {savings > 0 && (
                <div className="flex justify-between text-sm text-chart-5">
                  <span>পণ্যের ছাড়</span>
                  <span>-{formatTaka(savings)}</span>
                </div>
              )}
              {couponAmount > 0 && (
                <div className="flex justify-between text-sm text-chart-5">
                  <span>কুপন ছাড়</span>
                  <span>-{formatTaka(couponAmount)}</span>
                </div>
              )}
              <div className="my-1 border-t" />
              <div className="flex justify-between text-base font-bold">
                <span>সর্বমোট (ডেলিভারি ছাড়া)</span>
                <span className="text-primary">{formatTaka(total)}</span>
              </div>
              <Button size="lg" className="mt-2 rounded-full" nativeButton={false} render={<Link href="/checkout" />}>
                চেকআউটে যান
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
