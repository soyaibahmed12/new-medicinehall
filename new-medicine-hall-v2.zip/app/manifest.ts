import type { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'New Medicine Hall — অনলাইন ফার্মেসি',
    short_name: 'Medicine Hall',
    description: 'ঘরে বসে ১০০% আসল ঔষধ ও হেলথ প্রোডাক্ট অর্ডার করুন।',
    start_url: '/',
    scope: '/',
    display: 'standalone',
    orientation: 'portrait',
    background_color: '#f7fbfa',
    theme_color: '#0f766e',
    lang: 'bn',
    categories: ['medical', 'health', 'shopping'],
    icons: [
      { src: '/icons/nmh-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/icons/nmh-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icons/nmh-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
    shortcuts: [
      { name: 'আমার কার্ট', url: '/cart', icons: [{ src: '/icons/nmh-192.png', sizes: '192x192' }] },
      { name: 'সকল ঔষধ', url: '/products', icons: [{ src: '/icons/nmh-192.png', sizes: '192x192' }] },
    ],
  }
}
