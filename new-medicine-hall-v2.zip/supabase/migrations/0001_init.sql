-- ============================================================================
-- New Medicine Hall — core schema (Admin / Seller / User roles, products, orders)
-- Run this once in Supabase SQL Editor (or `supabase db push`) on a fresh project.
-- ============================================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- 1. Profiles (one row per auth.users row). Role is the single source of truth
--    for access control: 'user' | 'seller' | 'admin'.
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text not null default '',
  phone text not null default '',
  avatar_url text,
  role text not null default 'user' check (role in ('user', 'seller', 'admin')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- helper: is the current session an admin? security definer -> bypasses RLS
-- internally so it never recurses into the policies that call it.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.is_seller_or_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role in ('seller', 'admin')
  );
$$;

drop policy if exists "profiles_select" on public.profiles;
create policy "profiles_select"
  on public.profiles for select
  using (auth.uid() = id or public.is_admin());

drop policy if exists "profiles_update" on public.profiles;
create policy "profiles_update"
  on public.profiles for update
  using (auth.uid() = id or public.is_admin())
  with check (auth.uid() = id or public.is_admin());

-- A user can never grant themselves seller/admin by editing their own row —
-- only an admin session may change the `role` column.
create or replace function public.prevent_role_self_escalation()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.role is distinct from old.role and not public.is_admin() then
    new.role := old.role;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_prevent_role_self_escalation on public.profiles;
create trigger trg_prevent_role_self_escalation
  before update on public.profiles
  for each row execute function public.prevent_role_self_escalation();

-- Auto-create a profile whenever someone registers.
-- The very first person to ever register becomes admin automatically
-- (bootstrap) — every account after that starts as a plain 'user'.
-- Only that admin can promote someone else to 'seller' from /admin/users.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  first_ever boolean;
begin
  select not exists (select 1 from public.profiles) into first_ever;
  insert into public.profiles (id, full_name, phone, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'phone', ''),
    case when first_ever then 'admin' else 'user' end
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- 2. Products — any type of medicine (not just allopathic), owned by a seller.
-- ---------------------------------------------------------------------------
do $$ begin
  create type public.medicine_type as enum ('allopathic', 'ayurvedic', 'homeopathic', 'unani', 'herbal', 'other');
exception when duplicate_object then null;
end $$;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles (id) on delete cascade,
  name text not null,
  slug text not null unique,
  generic text not null default '',
  strength text not null default '',
  form text not null default '',
  company text not null default '',
  category text not null default 'medicine',
  medicine_type public.medicine_type not null default 'allopathic',
  image_url text,
  price numeric(10, 2) not null check (price >= 0),
  mrp numeric(10, 2) not null check (mrp >= 0),
  stock integer not null default 0 check (stock >= 0),
  rx boolean not null default false,
  rating numeric(2, 1) not null default 4.5,
  reviews integer not null default 0,
  sold integer not null default 0,
  tags text[] not null default '{}',
  description text not null default '',
  uses text[] not null default '{}',
  dosage text not null default '',
  side_effects text[] not null default '{}',
  warnings text not null default '',
  status text not null default 'active' check (status in ('active', 'hidden')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists products_seller_id_idx on public.products (seller_id);
create index if not exists products_category_idx on public.products (category);
create index if not exists products_medicine_type_idx on public.products (medicine_type);

alter table public.products enable row level security;

drop policy if exists "products_public_read" on public.products;
create policy "products_public_read"
  on public.products for select
  using (status = 'active' or seller_id = auth.uid() or public.is_admin());

drop policy if exists "products_insert" on public.products;
create policy "products_insert"
  on public.products for insert
  with check (seller_id = auth.uid() and public.is_seller_or_admin());

drop policy if exists "products_update" on public.products;
create policy "products_update"
  on public.products for update
  using (seller_id = auth.uid() or public.is_admin())
  with check (seller_id = auth.uid() or public.is_admin());

drop policy if exists "products_delete" on public.products;
create policy "products_delete"
  on public.products for delete
  using (seller_id = auth.uid() or public.is_admin());

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_products_updated_at on public.products;
create trigger trg_products_updated_at
  before update on public.products
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- 3. Orders — placed only by logged-in users (enforced in the app + RLS).
-- ---------------------------------------------------------------------------
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_no text not null unique,
  user_id uuid not null references public.profiles (id) on delete cascade,
  items jsonb not null,
  subtotal numeric(10, 2) not null,
  delivery_fee numeric(10, 2) not null default 0,
  total numeric(10, 2) not null,
  full_name text not null,
  phone text not null,
  address text not null,
  zone text not null,
  payment_method text not null,
  status text not null default 'placed' check (status in ('placed', 'confirmed', 'shipped', 'delivered', 'cancelled')),
  created_at timestamptz not null default now()
);

create index if not exists orders_user_id_idx on public.orders (user_id);

alter table public.orders enable row level security;

drop policy if exists "orders_select" on public.orders;
create policy "orders_select"
  on public.orders for select
  using (user_id = auth.uid() or public.is_admin());

drop policy if exists "orders_insert" on public.orders;
create policy "orders_insert"
  on public.orders for insert
  with check (user_id = auth.uid());

drop policy if exists "orders_update" on public.orders;
create policy "orders_update"
  on public.orders for update
  using (public.is_admin())
  with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- 4. Storage — public product image bucket, uploadable only by sellers/admins,
--    directly from the browser (including phone camera capture).
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

drop policy if exists "product_images_public_read" on storage.objects;
create policy "product_images_public_read"
  on storage.objects for select
  using (bucket_id = 'product-images');

drop policy if exists "product_images_insert" on storage.objects;
create policy "product_images_insert"
  on storage.objects for insert
  with check (bucket_id = 'product-images' and public.is_seller_or_admin());

drop policy if exists "product_images_modify_own" on storage.objects;
create policy "product_images_modify_own"
  on storage.objects for update
  using (bucket_id = 'product-images' and owner = auth.uid());

drop policy if exists "product_images_delete_own" on storage.objects;
create policy "product_images_delete_own"
  on storage.objects for delete
  using (bucket_id = 'product-images' and (owner = auth.uid() or public.is_admin()));
