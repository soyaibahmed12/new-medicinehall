import type { NextRequest } from 'next/server'
import { updateSession } from '@/lib/supabase/proxy'

export async function proxy(request: NextRequest) {
  return updateSession(request)
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|sw.js|icons|banners|.*\\.(?:svg|png|jpg|jpeg|gif|webp|json|txt|xml)$).*)'],
}
