export type Category = {
  slug: string
  name: string
  en: string
  icon: string
  tint: string
}

export type Pack = {
  id: string
  label: string
  price: number
  mrp: number
}

export type MedicineType = 'allopathic' | 'ayurvedic' | 'homeopathic' | 'unani' | 'herbal' | 'other'

export const medicineTypes: { value: MedicineType; label: string }[] = [
  { value: 'allopathic', label: 'এলোপ্যাথিক' },
  { value: 'ayurvedic', label: 'আয়ুর্বেদিক' },
  { value: 'homeopathic', label: 'হোমিওপ্যাথিক' },
  { value: 'unani', label: 'ইউনানি' },
  { value: 'herbal', label: 'হারবাল' },
  { value: 'other', label: 'অন্যান্য' },
]

export function medicineTypeLabel(v: string) {
  return medicineTypes.find((m) => m.value === v)?.label ?? v
}

export type Product = {
  id: string
  slug: string
  name: string
  generic: string
  strength: string
  form: string
  company: string
  category: string
  medicineType: MedicineType
  sellerId?: string
  image: string
  rating: number
  reviews: number
  sold: number
  rx: boolean
  stock: number
  tags: ('bestseller' | 'flash' | 'new' | 'trending')[]
  packs: Pack[]
  description: string
  uses: string[]
  dosage: string
  sideEffects: string[]
  warnings: string
}

export const categories: Category[] = [
  { slug: 'medicine', name: 'সাধারণ ঔষধ', en: 'Medicine', icon: 'pill', tint: 'bg-chart-1/10 text-chart-1' },
  { slug: 'diabetes', name: 'ডায়াবেটিস কেয়ার', en: 'Diabetes', icon: 'droplet', tint: 'bg-chart-3/10 text-chart-3' },
  { slug: 'heart', name: 'হার্ট ও প্রেশার', en: 'Heart & BP', icon: 'heart-pulse', tint: 'bg-destructive/10 text-destructive' },
  { slug: 'vitamins', name: 'ভিটামিন ও সাপ্লিমেন্ট', en: 'Vitamins', icon: 'citrus', tint: 'bg-chart-4/15 text-chart-2' },
  { slug: 'respiratory', name: 'শ্বাসতন্ত্র ও অ্যালার্জি', en: 'Respiratory', icon: 'wind', tint: 'bg-chart-3/10 text-chart-3' },
  { slug: 'gastro', name: 'গ্যাস্ট্রিক ও হজম', en: 'Gastro', icon: 'flame', tint: 'bg-deal/10 text-deal' },
  { slug: 'eye-care', name: 'চোখ ও কান', en: 'Eye & Ear', icon: 'eye', tint: 'bg-chart-5/10 text-chart-5' },
  { slug: 'skin', name: 'ত্বক পরিচর্যা', en: 'Skin Care', icon: 'sparkles', tint: 'bg-chart-2/10 text-chart-2' },
  { slug: 'baby', name: 'মা ও শিশু', en: 'Mom & Baby', icon: 'baby', tint: 'bg-chart-3/10 text-chart-3' },
  { slug: 'devices', name: 'মেডিকেল ডিভাইস', en: 'Devices', icon: 'stethoscope', tint: 'bg-chart-1/10 text-chart-1' },
  { slug: 'personal', name: 'পার্সোনাল কেয়ার', en: 'Personal Care', icon: 'hand-heart', tint: 'bg-chart-5/10 text-chart-5' },
  { slug: 'herbal', name: 'হারবাল ও ইউনানী', en: 'Herbal', icon: 'leaf', tint: 'bg-chart-5/10 text-chart-5' },
]

type Seed = Omit<Product, 'medicineType' | 'sellerId' | 'id' | 'slug' | 'packs' | 'uses' | 'sideEffects' | 'warnings' | 'dosage'> & {
  unit: number
  mrp: number
  unitLabel: string
  boxOf?: number
  uses?: string[]
  sideEffects?: string[]
  warnings?: string
  dosage?: string
}

function slugify(s: string) {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
}

function build(seed: Seed, index: number): Product {
  const { unit, mrp, unitLabel, boxOf, ...rest } = seed
  const packs: Pack[] = [{ id: 'unit', label: unitLabel, price: unit, mrp }]
  if (boxOf) {
    packs.push({
      id: 'box',
      label: `বক্স (${boxOf.toLocaleString('bn-BD')} ${unitLabel.includes('স্ট্রিপ') ? 'স্ট্রিপ' : 'পিস'})`,
      price: Math.round(unit * boxOf * 0.95),
      mrp: mrp * boxOf,
    })
  }
  return {
    ...rest,
    id: `p${index + 1}`,
    slug: slugify(`${seed.name} ${seed.strength}`),
    medicineType: seed.category === 'herbal' ? 'herbal' : 'allopathic',
    packs,
    uses: seed.uses ?? ['চিকিৎসকের পরামর্শ অনুযায়ী ব্যবহার করুন'],
    sideEffects: seed.sideEffects ?? ['সাধারণত পার্শ্বপ্রতিক্রিয়া বিরল', 'অস্বস্তি হলে চিকিৎসকের পরামর্শ নিন'],
    warnings: seed.warnings ?? 'শিশুদের নাগালের বাইরে, ঠান্ডা ও শুকনো স্থানে রাখুন।',
    dosage: seed.dosage ?? 'রেজিস্টার্ড চিকিৎসকের পরামর্শ অনুযায়ী সেবন করুন।',
  }
}

const seeds: Seed[] = [
  {
    name: 'Napa Extend', generic: 'Paracetamol', strength: '665 mg', form: 'ট্যাবলেট', company: 'Beximco Pharmaceuticals',
    category: 'medicine', image: '/products/tablet-box.png', rating: 4.8, reviews: 2381, sold: 18200, rx: false, stock: 540,
    tags: ['bestseller', 'flash'], unit: 18, mrp: 20, unitLabel: '১ স্ট্রিপ (১০ টি)', boxOf: 15,
    description: 'দীর্ঘস্থায়ী ব্যথা ও জ্বর নিরাময়ে কার্যকর এক্সটেন্ডেড রিলিজ প্যারাসিটামল ট্যাবলেট।',
    uses: ['জ্বর', 'মাথাব্যথা', 'বাতের ব্যথা', 'দাঁতের ব্যথা'], dosage: 'প্রাপ্তবয়স্ক: ২ টি ট্যাবলেট দিনে ৩ বার, ২৪ ঘণ্টায় ৬ টির বেশি নয়।',
    sideEffects: ['খুব কম ক্ষেত্রে এলার্জি', 'অতিরিক্ত মাত্রায় লিভারের ক্ষতি'],
  },
  {
    name: 'Seclo', generic: 'Omeprazole', strength: '20 mg', form: 'ক্যাপসুল', company: 'Square Pharmaceuticals',
    category: 'gastro', image: '/products/capsule-strip.png', rating: 4.7, reviews: 1842, sold: 14100, rx: false, stock: 380,
    tags: ['bestseller'], unit: 60, mrp: 70, unitLabel: '১ স্ট্রিপ (১০ টি)', boxOf: 10,
    description: 'অ্যাসিডিটি, গ্যাস্ট্রিক আলসার ও বুক জ্বালাপোড়া কমাতে ব্যবহৃত প্রোটন পাম্প ইনহিবিটর।',
    uses: ['অ্যাসিডিটি', 'গ্যাস্ট্রিক আলসার', 'GERD'], dosage: 'দিনে ১ বার খাবারের ৩০ মিনিট আগে।',
  },
  {
    name: 'Maxpro', generic: 'Esomeprazole', strength: '20 mg', form: 'ট্যাবলেট', company: 'Renata Limited',
    category: 'gastro', image: '/products/tablet-box.png', rating: 4.6, reviews: 964, sold: 8800, rx: false, stock: 210,
    tags: ['trending', 'flash'], unit: 70, mrp: 80, unitLabel: '১ স্ট্রিপ (১০ টি)', boxOf: 10,
    description: 'দীর্ঘমেয়াদি গ্যাস্ট্রিক সমস্যা ও রিফ্লাক্স নিয়ন্ত্রণে কার্যকর।',
    uses: ['রিফ্লাক্স', 'বুক জ্বালাপোড়া', 'পেপটিক আলসার'],
  },
  {
    name: 'Fexo', generic: 'Fexofenadine', strength: '120 mg', form: 'ট্যাবলেট', company: 'Square Pharmaceuticals',
    category: 'respiratory', image: '/products/tablet-box.png', rating: 4.7, reviews: 1120, sold: 9600, rx: false, stock: 320,
    tags: ['bestseller'], unit: 90, mrp: 100, unitLabel: '১ স্ট্রিপ (১০ টি)', boxOf: 5,
    description: 'অ্যালার্জি, হাঁচি, নাক দিয়ে পানি পড়া ও চুলকানি কমাতে ঘুম-না-আনা অ্যান্টিহিস্টামিন।',
    uses: ['সিজনাল অ্যালার্জি', 'চুলকানি', 'আর্টিকেরিয়া'],
  },
  {
    name: 'Monas', generic: 'Montelukast', strength: '10 mg', form: 'ট্যাবলেট', company: 'ACME Laboratories',
    category: 'respiratory', image: '/products/tablet-box.png', rating: 4.6, reviews: 702, sold: 5100, rx: true, stock: 190,
    tags: [], unit: 160, mrp: 175, unitLabel: '১ স্ট্রিপ (১০ টি)', boxOf: 3,
    description: 'অ্যাজমা ও অ্যালার্জিক রাইনাইটিস প্রতিরোধে ব্যবহৃত লিউকোট্রিন রিসেপ্টর অ্যান্টাগনিস্ট।',
    uses: ['অ্যাজমা প্রতিরোধ', 'অ্যালার্জিক রাইনাইটিস'],
  },
  {
    name: 'Azmasol Inhaler', generic: 'Salbutamol', strength: '100 mcg', form: 'ইনহেলার', company: 'Beximco Pharmaceuticals',
    category: 'respiratory', image: '/products/inhaler.png', rating: 4.8, reviews: 530, sold: 3900, rx: true, stock: 75,
    tags: ['trending'], unit: 295, mrp: 320, unitLabel: '১ ইনহেলার (২০০ ডোজ)',
    description: 'শ্বাসকষ্ট ও অ্যাজমার তাৎক্ষণিক উপশমে ব্যবহৃত ব্রঙ্কোডাইলেটর ইনহেলার।',
    uses: ['অ্যাজমা অ্যাটাক', 'COPD', 'শ্বাসকষ্ট'],
  },
  {
    name: 'Adovas Syrup', generic: 'Herbal Cough Syrup', strength: '100 ml', form: 'সিরাপ', company: 'Square Herbal',
    category: 'herbal', image: '/products/syrup.png', rating: 4.5, reviews: 640, sold: 7200, rx: false, stock: 260,
    tags: ['flash'], unit: 95, mrp: 110, unitLabel: '১ বোতল (১০০ মি.লি.)',
    description: 'বাসক পাতা সমৃদ্ধ ভেষজ কাশির সিরাপ, শুকনো ও কফযুক্ত কাশিতে আরাম দেয়।',
    uses: ['কাশি', 'গলা খুসখুস', 'ঠান্ডা'],
  },
  {
    name: 'Napa Syrup', generic: 'Paracetamol', strength: '120 mg/5 ml', form: 'সিরাপ', company: 'Beximco Pharmaceuticals',
    category: 'baby', image: '/products/syrup.png', rating: 4.8, reviews: 890, sold: 6500, rx: false, stock: 300,
    tags: ['bestseller'], unit: 35, mrp: 40, unitLabel: '১ বোতল (৬০ মি.লি.)',
    description: 'শিশুদের জ্বর ও ব্যথা কমাতে নিরাপদ প্যারাসিটামল সাসপেনশন।',
    uses: ['শিশুর জ্বর', 'দাঁত ওঠার ব্যথা', 'টিকা পরবর্তী জ্বর'],
  },
  {
    name: 'Mixtard 30 Penfill', generic: 'Human Insulin', strength: '100 IU/ml', form: 'ইনসুলিন', company: 'Novo Nordisk',
    category: 'diabetes', image: '/products/insulin-pen.png', rating: 4.9, reviews: 410, sold: 2800, rx: true, stock: 48,
    tags: ['bestseller'], unit: 620, mrp: 650, unitLabel: '১ পেনফিল (৩ মি.লি.)', boxOf: 5,
    description: 'টাইপ ১ ও টাইপ ২ ডায়াবেটিসে রক্তের গ্লুকোজ নিয়ন্ত্রণে প্রিমিক্সড হিউম্যান ইনসুলিন। কোল্ড চেইনে ডেলিভারি।',
    uses: ['টাইপ ১ ডায়াবেটিস', 'টাইপ ২ ডায়াবেটিস'], warnings: '২°-৮° সেলসিয়াসে ফ্রিজে রাখুন, জমাবেন না।',
  },
  {
    name: 'Comet', generic: 'Metformin', strength: '500 mg', form: 'ট্যাবলেট', company: 'Square Pharmaceuticals',
    category: 'diabetes', image: '/products/tablet-box.png', rating: 4.6, reviews: 720, sold: 6100, rx: true, stock: 410,
    tags: [], unit: 50, mrp: 55, unitLabel: '১ স্ট্রিপ (১০ টি)', boxOf: 10,
    description: 'টাইপ ২ ডায়াবেটিস নিয়ন্ত্রণে প্রথম সারির ঔষধ।',
    uses: ['টাইপ ২ ডায়াবেটিস', 'PCOS'],
  },
  {
    name: 'Accu-Chek Active', generic: 'Glucometer Kit', strength: '১০ স্ট্রিপ সহ', form: 'ডিভাইস', company: 'Roche',
    category: 'diabetes', image: '/products/glucometer.png', rating: 4.7, reviews: 318, sold: 1500, rx: false, stock: 36,
    tags: ['trending', 'flash'], unit: 1650, mrp: 1950, unitLabel: '১ কিট',
    description: 'মাত্র ৫ সেকেন্ডে সঠিক রক্তের গ্লুকোজ রিডিং, ৫০০ রিডিং মেমোরি।',
    uses: ['ঘরে বসে সুগার পরীক্ষা'],
  },
  {
    name: 'Bisocor', generic: 'Bisoprolol', strength: '5 mg', form: 'ট্যাবলেট', company: 'Healthcare Pharmaceuticals',
    category: 'heart', image: '/products/tablet-box.png', rating: 4.6, reviews: 388, sold: 3300, rx: true, stock: 260,
    tags: [], unit: 80, mrp: 90, unitLabel: '১ স্ট্রিপ (১০ টি)', boxOf: 3,
    description: 'উচ্চ রক্তচাপ ও হৃদরোগ নিয়ন্ত্রণে ব্যবহৃত বিটা ব্লকার।',
    uses: ['উচ্চ রক্তচাপ', 'এনজাইনা', 'হার্ট ফেইলিউর'],
  },
  {
    name: 'Rosuva', generic: 'Rosuvastatin', strength: '10 mg', form: 'ট্যাবলেট', company: 'Square Pharmaceuticals',
    category: 'heart', image: '/products/tablet-box.png', rating: 4.5, reviews: 276, sold: 2600, rx: true, stock: 180,
    tags: ['new'], unit: 180, mrp: 200, unitLabel: '১ স্ট্রিপ (১০ টি)', boxOf: 3,
    description: 'রক্তের কোলেস্টেরল কমিয়ে হৃদরোগের ঝুঁকি হ্রাস করে।',
    uses: ['উচ্চ কোলেস্টেরল', 'হৃদরোগ প্রতিরোধ'],
  },
  {
    name: 'Omron HEM-7120', generic: 'Digital BP Monitor', strength: 'আপার আর্ম', form: 'ডিভাইস', company: 'Omron Healthcare',
    category: 'devices', image: '/products/bp-monitor.png', rating: 4.8, reviews: 612, sold: 2100, rx: false, stock: 42,
    tags: ['bestseller', 'flash'], unit: 3450, mrp: 4200, unitLabel: '১ পিস',
    description: 'এক বোতাম চাপেই সঠিক রক্তচাপ ও পালস পরিমাপ। ৫ বছরের ওয়ারেন্টি।',
    uses: ['রক্তচাপ পরিমাপ', 'পালস রেট'],
  },
  {
    name: 'Digital Thermometer + Oximeter', generic: 'Health Monitor Combo', strength: 'কম্বো', form: 'ডিভাইস', company: 'Yuwell',
    category: 'devices', image: '/products/thermometer.png', rating: 4.5, reviews: 245, sold: 1900, rx: false, stock: 64,
    tags: ['new'], unit: 1250, mrp: 1600, unitLabel: '১ সেট',
    description: 'শরীরের তাপমাত্রা ও অক্সিজেন স্যাচুরেশন (SpO2) দ্রুত পরিমাপের কম্বো।',
    uses: ['জ্বর পরিমাপ', 'SpO2 ও পালস পরিমাপ'],
  },
  {
    name: 'Filwel Gold', generic: 'Multivitamin & Multimineral', strength: '৩০ টি', form: 'ট্যাবলেট', company: 'Square Pharmaceuticals',
    category: 'vitamins', image: '/products/vitamin.png', rating: 4.7, reviews: 805, sold: 5400, rx: false, stock: 150,
    tags: ['bestseller', 'trending'], unit: 390, mrp: 450, unitLabel: '১ কৌটা (৩০ টি)',
    description: 'প্রতিদিনের পুষ্টি ঘাটতি পূরণে সম্পূর্ণ মাল্টিভিটামিন ও মিনারেল।',
    uses: ['দুর্বলতা', 'রোগ প্রতিরোধ ক্ষমতা বৃদ্ধি'],
  },
  {
    name: 'Ceevit', generic: 'Vitamin C', strength: '250 mg', form: 'চুষে খাওয়ার ট্যাবলেট', company: 'Square Pharmaceuticals',
    category: 'vitamins', image: '/products/vitamin.png', rating: 4.6, reviews: 1290, sold: 11000, rx: false, stock: 600,
    tags: ['flash'], unit: 25, mrp: 30, unitLabel: '১ স্ট্রিপ (১০ টি)', boxOf: 10,
    description: 'অরেঞ্জ ফ্লেভারের ভিটামিন সি, রোগ প্রতিরোধ ক্ষমতা বাড়ায়।',
    uses: ['ভিটামিন সি ঘাটতি', 'ঠান্ডা-সর্দি প্রতিরোধ'],
  },
  {
    name: 'Moxiquin Eye Drops', generic: 'Moxifloxacin', strength: '0.5%', form: 'আই ড্রপ', company: 'Aristopharma',
    category: 'eye-care', image: '/products/eye-drops.png', rating: 4.5, reviews: 198, sold: 1700, rx: true, stock: 90,
    tags: [], unit: 150, mrp: 165, unitLabel: '১ বোতল (৫ মি.লি.)',
    description: 'চোখের ব্যাকটেরিয়াজনিত সংক্রমণ ও কনজাংটিভাইটিসে কার্যকর অ্যান্টিবায়োটিক ড্রপ।',
    uses: ['কনজাংটিভাইটিস', 'চোখের সংক্রমণ'],
  },
  {
    name: 'Tears Naturale', generic: 'Lubricant Eye Drops', strength: '15 ml', form: 'আই ড্রপ', company: 'Alcon',
    category: 'eye-care', image: '/products/eye-drops.png', rating: 4.4, reviews: 150, sold: 1200, rx: false, stock: 70,
    tags: ['new'], unit: 280, mrp: 320, unitLabel: '১ বোতল (১৫ মি.লি.)',
    description: 'স্ক্রিন ব্যবহারে চোখের শুষ্কতা ও জ্বালাপোড়া থেকে আরাম।',
    uses: ['ড্রাই আই', 'চোখের ক্লান্তি'],
  },
  {
    name: 'Fungidal HC Cream', generic: 'Miconazole + Hydrocortisone', strength: '10 g', form: 'ক্রিম', company: 'ACI Limited',
    category: 'skin', image: '/products/ointment.png', rating: 4.4, reviews: 310, sold: 2900, rx: false, stock: 140,
    tags: [], unit: 85, mrp: 95, unitLabel: '১ টিউব (১০ গ্রাম)',
    description: 'ছত্রাকজনিত চর্মরোগ, দাদ ও চুলকানিতে কার্যকর ক্রিম।',
    uses: ['দাদ', 'ছত্রাক সংক্রমণ', 'চুলকানি'],
  },
  {
    name: 'Savlon Hand Sanitizer + Mask', generic: 'Hygiene Combo', strength: '২৫০ মি.লি. + ৫০ মাস্ক', form: 'কম্বো', company: 'ACI Limited',
    category: 'personal', image: '/products/mask-sanitizer.png', rating: 4.6, reviews: 520, sold: 4800, rx: false, stock: 220,
    tags: ['flash'], unit: 399, mrp: 520, unitLabel: '১ কম্বো',
    description: '৯৯.৯% জীবাণু ধ্বংসকারী স্যানিটাইজার ও ৩-প্লাই সার্জিক্যাল মাস্কের সাশ্রয়ী কম্বো।',
    uses: ['হাত জীবাণুমুক্ত রাখা', 'সংক্রমণ প্রতিরোধ'],
  },
  {
    name: 'Baby Care Essentials', generic: 'Lotion + Powder + Diaper', strength: 'মিডিয়াম', form: 'কম্বো', company: 'Johnson & Johnson',
    category: 'baby', image: '/products/baby-care.png', rating: 4.7, reviews: 430, sold: 2300, rx: false, stock: 58,
    tags: ['trending'], unit: 1490, mrp: 1750, unitLabel: '১ কম্বো',
    description: 'নবজাতকের নিত্যপ্রয়োজনীয় লোশন, পাউডার ও ডায়াপারের কম্বো প্যাক।',
    uses: ['শিশুর ত্বকের যত্ন'],
  },
  {
    name: 'Hamdard Safi', generic: 'Blood Purifier', strength: '200 ml', form: 'সিরাপ', company: 'Hamdard Laboratories',
    category: 'herbal', image: '/products/herbal.png', rating: 4.5, reviews: 760, sold: 6400, rx: false, stock: 175,
    tags: ['bestseller'], unit: 230, mrp: 260, unitLabel: '১ বোতল (২০০ মি.লি.)',
    description: 'ত্বকের উজ্জ্বলতা বাড়াতে ও রক্ত পরিষ্কারে জনপ্রিয় ইউনানী টনিক।',
    uses: ['ব্রণ', 'ত্বকের সমস্যা'],
  },
  {
    name: 'Alatrol', generic: 'Cetirizine', strength: '10 mg', form: 'ট্যাবলেট', company: 'Square Pharmaceuticals',
    category: 'respiratory', image: '/products/tablet-box.png', rating: 4.6, reviews: 980, sold: 12400, rx: false, stock: 0,
    tags: [], unit: 30, mrp: 35, unitLabel: '১ স্ট্রিপ (১০ টি)', boxOf: 10,
    description: 'হাঁচি, সর্দি ও অ্যালার্জিজনিত চুলকানি উপশমে দ্রুত কার্যকর।',
    uses: ['সর্দি', 'অ্যালার্জি', 'চুলকানি'],
  },
]

export const products: Product[] = seeds.map(build)

export const productById = new Map(products.map((p) => [p.id, p]))
export const productBySlug = new Map(products.map((p) => [p.slug, p]))

export const brands = Array.from(new Set(products.map((p) => p.company))).sort()

export function categoryName(slug: string) {
  return categories.find((c) => c.slug === slug)?.name ?? slug
}

export function discountPercent(pack: Pack) {
  if (pack.mrp <= pack.price) return 0
  return Math.round(((pack.mrp - pack.price) / pack.mrp) * 100)
}

export const DELIVERY = {
  insideDhaka: 60,
  outsideDhaka: 120,
  express: 99,
  freeOver: 1000,
}

export const COUPONS: Record<string, { label: string; percent?: number; flat?: number; max?: number; min?: number }> = {
  NMH10: { label: '১০% ছাড় (সর্বোচ্চ ৳২০০)', percent: 10, max: 200, min: 300 },
  FIRST50: { label: 'প্রথম অর্ডারে ৳৫০ ছাড়', flat: 50, min: 200 },
  HEALTH100: { label: '৳১৫০০+ অর্ডারে ৳১০০ ছাড়', flat: 100, min: 1500 },
}

export function couponDiscount(code: string, subtotal: number) {
  const c = COUPONS[code.trim().toUpperCase()]
  if (!c) return { ok: false as const, amount: 0, reason: 'কুপন কোডটি সঠিক নয়' }
  if (c.min && subtotal < c.min) {
    return { ok: false as const, amount: 0, reason: `কমপক্ষে ${formatTaka(c.min)} অর্ডার প্রয়োজন` }
  }
  let amount = c.flat ?? 0
  if (c.percent) amount = Math.round((subtotal * c.percent) / 100)
  if (c.max) amount = Math.min(amount, c.max)
  return { ok: true as const, amount, reason: c.label }
}

export function formatTaka(n: number) {
  return `৳${n.toLocaleString('bn-BD')}`
}

export function bn(n: number) {
  return n.toLocaleString('bn-BD')
}
