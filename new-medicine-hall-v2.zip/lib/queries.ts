import { createClient } from '@/lib/supabase/server'
import type { MedicineType, Product } from '@/lib/catalog'

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function rowToProduct(r: any): Product {
  return {
    id: r.id,
    slug: r.slug,
    name: r.name,
    generic: r.generic ?? '',
    strength: r.strength ?? '',
    form: r.form ?? '',
    company: r.company ?? '',
    category: r.category,
    medicineType: r.medicine_type as MedicineType,
    sellerId: r.seller_id,
    image: r.image_url || '/products/placeholder.svg',
    rating: Number(r.rating),
    reviews: r.reviews,
    sold: r.sold,
    rx: r.rx,
    stock: r.stock,
    tags: (r.tags ?? []) as Product['tags'],
    packs: [{ id: 'unit', label: '১ ইউনিট', price: Number(r.price), mrp: Number(r.mrp) }],
    description: r.description ?? '',
    uses: r.uses?.length ? r.uses : ['চিকিৎসকের পরামর্শ অনুযায়ী ব্যবহার করুন'],
    dosage: r.dosage || 'রেজিস্টার্ড চিকিৎসকের পরামর্শ অনুযায়ী সেবন করুন।',
    sideEffects: r.side_effects?.length ? r.side_effects : ['অস্বস্তি হলে চিকিৎসকের পরামর্শ নিন'],
    warnings: r.warnings || 'শিশুদের নাগালের বাইরে, ঠান্ডা ও শুকনো স্থানে রাখুন।',
  }
}

export type ProductFilters = {
  category?: string
  type?: string
  q?: string
  deal?: string
  sort?: string
  tag?: string
  limit?: number
}

export async function getProducts(f: ProductFilters = {}): Promise<Product[]> {
  const supabase = await createClient()
  let query = supabase.from('products').select('*').eq('status', 'active')
  if (f.category) query = query.eq('category', f.category)
  if (f.type) query = query.eq('medicine_type', f.type)
  if (f.deal === 'flash') query = query.contains('tags', ['flash'])
  if (f.tag) query = query.contains('tags', [f.tag])
  if (f.q) {
    const t = f.q.trim().replace(/[%,()]/g, ' ')
    query = query.or(`name.ilike.%${t}%,generic.ilike.%${t}%,company.ilike.%${t}%`)
  }
  switch (f.sort) {
    case 'price-asc':
      query = query.order('price', { ascending: true })
      break
    case 'price-desc':
      query = query.order('price', { ascending: false })
      break
    case 'bestseller':
      query = query.order('sold', { ascending: false })
      break
    case 'new':
      query = query.order('created_at', { ascending: false })
      break
    default:
      query = query.order('rating', { ascending: false }).order('created_at', { ascending: false })
  }
  if (f.limit) query = query.limit(f.limit)
  const { data } = await query
  return (data ?? []).map(rowToProduct)
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const supabase = await createClient()
  const { data } = await supabase.from('products').select('*').eq('slug', slug).eq('status', 'active').maybeSingle()
  return data ? rowToProduct(data) : null
}

export async function getProductsByIds(ids: string[]): Promise<Product[]> {
  if (!ids.length) return []
  const supabase = await createClient()
  const { data } = await supabase.from('products').select('*').in('id', ids).eq('status', 'active')
  return (data ?? []).map(rowToProduct)
}
