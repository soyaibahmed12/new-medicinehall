'use client'

import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import type { Product } from '@/lib/catalog'

export type CartLine = { productId: string; packId: string; qty: number }

export const MAX_QTY_PER_LINE = 20

type ShopState = {
  cart: CartLine[]
  wishlist: string[]
  recent: string[]
  hydrated: boolean
  cartOpen: boolean
  snapshots: Record<string, Product>
  add: (productId: string, packId: string, qty?: number, product?: Product) => void
  setQty: (productId: string, packId: string, qty: number) => void
  remove: (productId: string, packId: string) => void
  clearCart: () => void
  toggleWish: (productId: string, product?: Product) => void
  pushRecent: (productId: string) => void
  setCartOpen: (open: boolean) => void
}

const clampQty = (q: number) => Math.max(1, Math.min(MAX_QTY_PER_LINE, Math.floor(q)))

export const useShop = create<ShopState>()(
  persist(
    (set) => ({
      cart: [],
      wishlist: [],
      recent: [],
      hydrated: false,
      cartOpen: false,
      snapshots: {},
      add: (productId, packId, qty = 1, product) =>
        set((s) => {
          const snapshots = product ? { ...s.snapshots, [productId]: product } : s.snapshots
          const existing = s.cart.find((l) => l.productId === productId && l.packId === packId)
          if (existing) {
            return {
              snapshots,
              cart: s.cart.map((l) => (l === existing ? { ...l, qty: clampQty(l.qty + qty) } : l)),
            }
          }
          return { snapshots, cart: [...s.cart, { productId, packId, qty: clampQty(qty) }] }
        }),
      setQty: (productId, packId, qty) =>
        set((s) => ({
          cart: s.cart.map((l) =>
            l.productId === productId && l.packId === packId ? { ...l, qty: clampQty(qty) } : l,
          ),
        })),
      remove: (productId, packId) =>
        set((s) => ({ cart: s.cart.filter((l) => !(l.productId === productId && l.packId === packId)) })),
      clearCart: () => set({ cart: [] }),
      toggleWish: (productId, product) =>
        set((s) => ({
          snapshots: product ? { ...s.snapshots, [productId]: product } : s.snapshots,
          wishlist: s.wishlist.includes(productId)
            ? s.wishlist.filter((id) => id !== productId)
            : [productId, ...s.wishlist],
        })),
      pushRecent: (productId) =>
        set((s) => ({ recent: [productId, ...s.recent.filter((id) => id !== productId)].slice(0, 12) })),
      setCartOpen: (open) => set({ cartOpen: open }),
    }),
    {
      name: 'nmh-shop',
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (s) => ({ cart: s.cart, wishlist: s.wishlist, recent: s.recent, snapshots: s.snapshots }),
      onRehydrateStorage: () => () => {
        useShop.setState({ hydrated: true })
      },
    },
  ),
)

export function resolveCart(cart: CartLine[]) {
  const lines = cart.flatMap((line) => {
    const product = useShop.getState().snapshots[line.productId]
    const pack = product?.packs.find((p) => p.id === line.packId)
    if (!product || !pack) return []
    return [{ ...line, product, pack, total: pack.price * line.qty, mrpTotal: pack.mrp * line.qty }]
  })
  const subtotal = lines.reduce((s, l) => s + l.total, 0)
  const mrpTotal = lines.reduce((s, l) => s + l.mrpTotal, 0)
  const count = lines.reduce((s, l) => s + l.qty, 0)
  return { lines, subtotal, mrpTotal, savings: mrpTotal - subtotal, count }
}
