import { cache } from 'react'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'

export type Role = 'user' | 'seller' | 'admin'
export type SessionUser = { id: string; email: string; fullName: string; phone: string; avatarUrl: string | null; role: Role }

export const getSessionUser = cache(async (): Promise<SessionUser | null> => {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return null
  const { data: profile } = await supabase.from('profiles').select('full_name, phone, avatar_url, role').eq('id', user.id).single()
  return {
    id: user.id,
    email: user.email ?? '',
    fullName: profile?.full_name ?? '',
    phone: profile?.phone ?? '',
    avatarUrl: profile?.avatar_url ?? null,
    role: (profile?.role as Role) ?? 'user',
  }
})

export async function requireUser(next = '/') {
  const user = await getSessionUser()
  if (!user) redirect(`/login?next=${encodeURIComponent(next)}`)
  return user
}

export async function requireRole(roles: Role[]) {
  const user = await requireUser()
  if (!roles.includes(user.role)) redirect('/')
  return user
}
