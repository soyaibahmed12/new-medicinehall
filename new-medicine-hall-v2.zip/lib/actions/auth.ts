'use server'

import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'
import { getSessionUser } from '@/lib/auth'

export type FormState = { error?: string; message?: string } | undefined

function safeNext(v: FormDataEntryValue | null) {
  const s = typeof v === 'string' ? v : '/'
  return s.startsWith('/') && !s.startsWith('//') ? s : '/'
}

export async function loginAction(_: FormState, fd: FormData): Promise<FormState> {
  const email = String(fd.get('email') ?? '').trim()
  const password = String(fd.get('password') ?? '')
  if (!email || !password) return { error: 'ইমেইল ও পাসওয়ার্ড দিন' }
  const supabase = await createClient()
  const { error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) return { error: 'ইমেইল অথবা পাসওয়ার্ড ভুল' }
  revalidatePath('/', 'layout')
  redirect(safeNext(fd.get('next')))
}

export async function registerAction(_: FormState, fd: FormData): Promise<FormState> {
  const fullName = String(fd.get('full_name') ?? '').trim()
  const phone = String(fd.get('phone') ?? '').trim()
  const email = String(fd.get('email') ?? '').trim()
  const password = String(fd.get('password') ?? '')
  if (fullName.length < 2) return { error: 'পুরো নাম লিখুন' }
  if (!/^01[0-9]{9}$/.test(phone)) return { error: 'সঠিক মোবাইল নম্বর দিন (01XXXXXXXXX)' }
  if (password.length < 8) return { error: 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে' }
  const supabase = await createClient()
  // Role is NOT accepted from the client: every new account is a plain 'user'.
  // Only an admin can promote someone to seller.
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { full_name: fullName, phone } },
  })
  if (error) return { error: error.message.includes('registered') ? 'এই ইমেইল দিয়ে আগেই অ্যাকাউন্ট আছে' : 'রেজিস্ট্রেশন ব্যর্থ হয়েছে, আবার চেষ্টা করুন' }
  if (!data.session) return { message: 'আপনার ইমেইলে একটি কনফার্মেশন লিংক পাঠানো হয়েছে। লিংকে ক্লিক করে লগইন করুন।' }
  revalidatePath('/', 'layout')
  redirect(safeNext(fd.get('next')))
}

export async function logoutAction() {
  const supabase = await createClient()
  await supabase.auth.signOut()
  revalidatePath('/', 'layout')
  redirect('/')
}

export async function updateProfileAction(_: FormState, fd: FormData): Promise<FormState> {
  const user = await getSessionUser()
  if (!user) return { error: 'আগে লগইন করুন' }
  const fullName = String(fd.get('full_name') ?? '').trim()
  const phone = String(fd.get('phone') ?? '').trim()
  const avatarUrl = String(fd.get('avatar_url') ?? '').trim() || null
  if (fullName.length < 2) return { error: 'পুরো নাম লিখুন' }
  if (!/^01[0-9]{9}$/.test(phone)) return { error: 'সঠিক মোবাইল নম্বর দিন' }
  const supabase = await createClient()
  const { error } = await supabase.from('profiles').update({ full_name: fullName, phone, avatar_url: avatarUrl }).eq('id', user.id)
  if (error) return { error: 'প্রোফাইল আপডেট করা যায়নি' }
  revalidatePath('/', 'layout')
  return { message: 'প্রোফাইল আপডেট হয়েছে' }
}
