'use server'

import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'
import { requireRole } from '@/lib/auth'

/** Only an admin can make (or remove) a seller. Enforced here AND by DB trigger/RLS. */
export async function setRoleAction(fd: FormData) {
  const admin = await requireRole(['admin'])
  const target = String(fd.get('id'))
  const role = String(fd.get('role'))
  if (!['user', 'seller'].includes(role) || target === admin.id) return
  const supabase = await createClient()
  await supabase.from('profiles').update({ role }).eq('id', target).neq('role', 'admin')
  revalidatePath('/admin/users')
}

export async function setOrderStatusAction(fd: FormData) {
  await requireRole(['admin'])
  const status = String(fd.get('status'))
  if (!['placed', 'confirmed', 'shipped', 'delivered', 'cancelled'].includes(status)) return
  const supabase = await createClient()
  await supabase.from('orders').update({ status }).eq('id', String(fd.get('id')))
  revalidatePath('/admin/orders')
}
