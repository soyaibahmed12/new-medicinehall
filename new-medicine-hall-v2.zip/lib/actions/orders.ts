'use server'

import { createClient } from '@/lib/supabase/server'
import { getSessionUser } from '@/lib/auth'
import { DELIVERY } from '@/lib/catalog'

export type PlaceOrderInput = {
  items: { productId: string; qty: number }[]
  fullName: string
  phone: string
  address: string
  zone: 'dhaka' | 'outside'
  payment: string
}

export async function placeOrderAction(input: PlaceOrderInput): Promise<{ orderNo?: string; error?: string }> {
  const user = await getSessionUser()
  if (!user) return { error: 'অর্ডার করতে আগে লগইন করুন' }
  if (!input.items.length) return { error: 'কার্ট খালি' }
  if (!/^01[0-9]{9}$/.test(input.phone)) return { error: 'সঠিক মোবাইল নম্বর দিন' }
  if (input.fullName.trim().length < 2 || input.address.trim().length < 8) return { error: 'নাম ও সম্পূর্ণ ঠিকানা দিন' }
  if (!['bkash', 'nagad', 'rocket', 'card', 'cod'].includes(input.payment)) return { error: 'পেমেন্ট পদ্ধতি সঠিক নয়' }

  const supabase = await createClient()
  const ids = input.items.map((i) => i.productId)
  const { data: rows } = await supabase.from('products').select('id, name, price, stock').in('id', ids).eq('status', 'active')
  const byId = new Map((rows ?? []).map((r) => [r.id as string, r]))

  // Prices always come from the database — never from the browser.
  const items = []
  let subtotal = 0
  for (const it of input.items) {
    const p = byId.get(it.productId)
    const qty = Math.max(1, Math.min(20, Math.floor(it.qty)))
    if (!p) return { error: 'কার্টের কিছু পণ্য আর পাওয়া যাচ্ছে না, কার্ট আপডেট করুন' }
    if (p.stock < qty) return { error: `"${p.name}" এর পর্যাপ্ত স্টক নেই` }
    const line = Number(p.price) * qty
    subtotal += line
    items.push({ productId: p.id, name: p.name, price: Number(p.price), qty, total: line })
  }
  const deliveryFee = subtotal >= DELIVERY.freeOver ? 0 : input.zone === 'dhaka' ? DELIVERY.insideDhaka : DELIVERY.outsideDhaka
  const orderNo = `NMH${Date.now().toString().slice(-8)}${Math.floor(Math.random() * 90 + 10)}`

  const { error } = await supabase.from('orders').insert({
    order_no: orderNo,
    user_id: user.id,
    items,
    subtotal,
    delivery_fee: deliveryFee,
    total: subtotal + deliveryFee,
    full_name: input.fullName.trim(),
    phone: input.phone,
    address: input.address.trim(),
    zone: input.zone,
    payment_method: input.payment,
  })
  if (error) return { error: 'অর্ডার সম্পন্ন করা যায়নি, আবার চেষ্টা করুন' }
  return { orderNo }
}

export async function searchProductsAction(q: string) {
  const { getProducts } = await import('@/lib/queries')
  const term = q.trim()
  if (term.length < 2) return []
  const list = await getProducts({ q: term, limit: 6 })
  return list.map((p) => ({ id: p.id, slug: p.slug, name: p.name, strength: p.strength, image: p.image, price: p.packs[0].price, generic: p.generic }))
}
