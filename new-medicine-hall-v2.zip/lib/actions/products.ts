'use server'

import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'
import { requireRole } from '@/lib/auth'
import { categories, medicineTypes } from '@/lib/catalog'
import type { FormState } from '@/lib/actions/auth'

const lines = (v: FormDataEntryValue | null) =>
  String(v ?? '')
    .split('\n')
    .map((s) => s.trim())
    .filter(Boolean)

function slugify(s: string) {
  const base = s
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60)
  return `${base || 'product'}-${Math.random().toString(36).slice(2, 7)}`
}

function parse(fd: FormData, isAdmin: boolean) {
  const name = String(fd.get('name') ?? '').trim()
  const price = Number(fd.get('price'))
  const mrp = Number(fd.get('mrp'))
  const stock = Math.floor(Number(fd.get('stock')))
  const category = String(fd.get('category') ?? '')
  const medicineType = String(fd.get('medicine_type') ?? '')
  if (name.length < 2) return { error: 'পণ্যের নাম দিন' as const }
  if (!(price >= 0) || !(mrp >= price)) return { error: 'বিক্রয়মূল্য অবশ্যই MRP এর সমান বা কম হতে হবে' as const }
  if (!(stock >= 0)) return { error: 'স্টক সঠিক নয়' as const }
  if (!categories.some((c) => c.slug === category)) return { error: 'ক্যাটাগরি বেছে নিন' as const }
  if (!medicineTypes.some((m) => m.value === medicineType)) return { error: 'ঔষধের ধরন বেছে নিন' as const }
  const imageUrl = String(fd.get('image_url') ?? '').trim()
  const row: Record<string, unknown> = {
    name,
    generic: String(fd.get('generic') ?? '').trim(),
    strength: String(fd.get('strength') ?? '').trim(),
    form: String(fd.get('form') ?? '').trim(),
    company: String(fd.get('company') ?? '').trim(),
    category,
    medicine_type: medicineType,
    image_url: imageUrl || null,
    price,
    mrp,
    stock,
    description: String(fd.get('description') ?? '').trim(),
    uses: lines(fd.get('uses')),
    dosage: String(fd.get('dosage') ?? '').trim(),
    side_effects: lines(fd.get('side_effects')),
    warnings: String(fd.get('warnings') ?? '').trim(),
    status: fd.get('status') === 'hidden' ? 'hidden' : 'active',
  }
  if (isAdmin) row.tags = fd.getAll('tags').map(String).filter((t) => ['bestseller', 'flash', 'new', 'trending'].includes(t))
  return { row }
}

export async function saveProductAction(_: FormState, fd: FormData): Promise<FormState> {
  const user = await requireRole(['seller', 'admin'])
  const parsed = parse(fd, user.role === 'admin')
  if ('error' in parsed) return { error: parsed.error }
  const supabase = await createClient()
  const id = String(fd.get('id') ?? '')
  if (id) {
    const { error } = await supabase.from('products').update(parsed.row).eq('id', id)
    if (error) return { error: 'পণ্য আপডেট করা যায়নি' }
  } else {
    const { error } = await supabase.from('products').insert({
      ...parsed.row,
      seller_id: user.id,
      slug: slugify(`${parsed.row.name} ${parsed.row.strength}`),
    })
    if (error) return { error: 'পণ্য যোগ করা যায়নি' }
  }
  revalidatePath('/', 'layout')
  redirect(user.role === 'admin' ? '/admin/products' : '/seller/products')
}

export async function deleteProductAction(fd: FormData) {
  await requireRole(['seller', 'admin'])
  const supabase = await createClient()
  await supabase.from('products').delete().eq('id', String(fd.get('id')))
  revalidatePath('/', 'layout')
}

export async function toggleProductStatusAction(fd: FormData) {
  await requireRole(['seller', 'admin'])
  const supabase = await createClient()
  const next = String(fd.get('status')) === 'active' ? 'hidden' : 'active'
  await supabase.from('products').update({ status: next }).eq('id', String(fd.get('id')))
  revalidatePath('/', 'layout')
}
